--/************************************************************************************************************
--*      Program name                     :               Skanska - PJC Expenditure Type Transfer 
--*                                                       (EXT0117)
--*      Source File Name                 :               XXPJC_E0117_EXPITM_TRANS_INPT_GRT.sql
--*      Copyright Information            :               SKANSKA
--*      Author's Name                    :               Sudeep Babu
--*      Purpose                          :               Grant script for the intermediate table XXPJC_E0117_EXPITM_TRANS_INPT
--*
--*      Creation and Modification History 
--*      Ver                             Date                   Author                       Modification
--* -----------------------------------------------------------------------------------------------------------*
--*      1.0                             03.12.2014             Sudeep Babu                  Initial Creation  
--*************************************************************************************************************/

GRANT ALL PRIVILEGES ON xxpjc_e0117_expitm_trans_inpt TO fusion_runtime;
GRANT ALL PRIVILEGES ON xxpjc_e0117_expitm_trans_inpt TO fusion;
/