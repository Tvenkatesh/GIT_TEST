--/************************************************************************************************************
--*      Program name                     :               Skanska - PJC Expenditure Type Transfer 
--*                                                       (EXT0117)
--*      Source File Name                 :               XXPJC_E0117_TRANS_ID_S_GRT.sql
--*      Copyright Information            :               SKANSKA
--*      Author's Name                    :               Sudeep Babu
--*      Purpose                          :               Sequence Grant script
--*      Creation and Modification History 
--*      Ver                             Date                   Author                       Modification
--* -----------------------------------------------------------------------------------------------------------*
--*      1.0                             03.12.2014             Sudeep Babu                  Initial Creation  
--*************************************************************************************************************/

GRANT  ALL  ON xxppm_e0117_trans_id_s TO fusion_runtime;
GRANT  ALL  ON xxppm_e0117_trans_id_s TO fusion;
/