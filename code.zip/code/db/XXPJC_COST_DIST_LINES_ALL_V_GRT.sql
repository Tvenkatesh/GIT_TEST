-- +========================================================================================================+
-- | PROGRAM NAME          : EXT0110 -                             |
-- | SOURCE FILE NAME      : XXPJC_COST_DIST_LINES_ALL_V.sql                                                    |
-- | COPYRIGHT INFORMATION : SKANSKA                                                                        |
-- | PURPOSE               : To Display Accounting data in Manage Expenditure Page                        |
-- | CALLED BY             : Project Expenditure Seeded Vo                                                 |
-- |                         
-- +========================================================================================================+
-- | MODIFICATION HISTORY                                                                                   |
-- | Author                  Ver #    Modification Date         Description of Change                       |
-- | Rahul Sharma             0.1      08 FEB 2016               Initial Creation     
-- +========================================================================================================+

GRANT ALL ON fusion.xxpjc_cost_dist_lines_all_v TO xx_fusion_custom;
GRANT ALL ON fusion.xxpjc_cost_dist_lines_all_v TO fusion_runtime;
GRANT ALL ON fusion.xxpjc_cost_dist_lines_all_v TO fusion_apps_execute;
GRANT SELECT ON fusion.xxpjc_cost_dist_lines_all_v TO fusion_read_only;


/
SHOW ERROR
/
