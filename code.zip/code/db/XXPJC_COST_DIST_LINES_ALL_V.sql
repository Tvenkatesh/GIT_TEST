CREATE OR REPLACE FORCE VIEW fusion.xxpjc_cost_dist_lines_all_v 
           (exp_item_id
           ,line_num
           ,prvdr_gl_date
           ,prvdr_pa_date
           ,line_type
           ,recvr_gl_date
           ,recvr_pa_date
          )
AS
-- +========================================================================================================+
-- | PROGRAM NAME          : EXT0117 -                                                                    |
-- | SOURCE FILE NAME      : XXPJC_COST_DIST_LINES_ALL_V.sql                                              |
-- | COPYRIGHT INFORMATION : SKANSKA                                                                      |
-- | PURPOSE               : To Display Accounting data in Manage Expenditure Page                        |
-- | CALLED BY             : Project Expenditure Seeded Vo                                                |
-- |                         
-- +========================================================================================================+
-- | MODIFICATION HISTORY                                                                                   |
-- | Author                  Ver #    Modification Date         Description of Change                       |
-- | Rahul Sharma             0.1      08 FEB 2016               Initial Creation    
-- | Ganapati Roy			  0.2      09 SEP 2016				 RFC 2879
-- |															Changing the current logic to pick the GL DATE 
-- |                                                            of expenditure lines from the table PJC_COST_DIST_LINES_ALL 
-- |															used within the custom view XXProjectCostDistEO ,
-- |															taking those records where REVERSED_FLAG is null
-- |														    and LINE_NUM_REVERSED is null
-- |															which gives unique record 	 
-- +========================================================================================================+
  (SELECT pcdla.expenditure_item_id,
           pcdla.line_num,
		   pcdla.prvdr_gl_date,
		   pcdla.prvdr_pa_date,
		   pcdla.line_type,
		   pcdla.recvr_gl_date,
		   pcdla.recvr_pa_date  
    FROM fusion.pjc_cost_dist_lines_all pcdla
	WHERE pcdla.REVERSED_FLAG is null
    AND pcdla.LINE_NUM_REVERSED is null);
/
SHOW ERROR
/
