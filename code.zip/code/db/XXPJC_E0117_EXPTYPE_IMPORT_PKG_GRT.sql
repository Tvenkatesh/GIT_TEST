--/************************************************************************************************************
--*      Program name                     :               Skanska - PJC Expenditure Type Transfer 
--*                                                       (EXT0117)
--*      Source File Name                 :               XXPJC_E0117_EXPTYPE_IMPORT_PKG_GRT.sql
--*      Copyright Information            :               SKANSKA
--*      Author's Name                    :               Sudeep Babu
--*      Purpose                          :               Grant script for the package
--*
--*      Creation and Modification History 
--*      Ver                             Date                   Author                       Modification
--* -----------------------------------------------------------------------------------------------------------*
--*      1.0                             03.12.2014             Sudeep Babu                  Initial Creation  
--*************************************************************************************************************/
GRANT ALL ON  xx_fusion_custom.xxpjc_e0117_exptype_import_pkg TO fusion;  
GRANT ALL ON  xx_fusion_custom.xxpjc_e0117_exptype_import_pkg TO fusion_runtime;  
/                            