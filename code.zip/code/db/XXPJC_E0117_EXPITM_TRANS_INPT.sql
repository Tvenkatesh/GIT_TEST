SET SERVEROUTPUT ON;
--/************************************************************************************************************
--*      Program name                     :               Skanska - PJC Expenditure Type Transfer 
--*                                                       (EXT0117)
--*      Source File Name                 :               XXPJC_E0117_EXPITM_TRANS_INPT_DDL.sql
--*      Copyright Information            :               SKANSKA
--*      Author's Name                    :               Sudeep Babu
--*      Purpose                          :               Creation script for the custom intermediate table
--*                                                       
--*      Creation and Modification History 
--*      Ver                             Date                   Author                       Modification
--* -----------------------------------------------------------------------------------------------------------*
--*      1.0                             03.12.2014             Sudeep Babu                  Initial Creation  
--*************************************************************************************************************/
   
DECLARE
   v_temp         NUMBER;
   v_table_name   VARCHAR2(50) ;
BEGIN
 v_temp  :=0;
   v_table_name   := 'XXPJC_E0117_EXPITM_TRANS_INPT';
   DBMS_OUTPUT.PUT_LINE ('Creating table '|| v_table_name|| ' in XX_FUSION_CUSTOM schema.');

   SELECT COUNT('x')
     INTO v_temp
     FROM all_tables
    WHERE table_name = UPPER(v_table_name);

   IF v_temp > 0 THEN
      DBMS_OUTPUT.put_line (  v_table_name || ' table already exists in NH_CUSTOM schema.');
   ELSE
      DBMS_OUTPUT.PUT_LINE('Creating table: '||v_table_name);
      EXECUTE IMMEDIATE 'CREATE TABLE XX_FUSION_CUSTOM.'||v_table_name||'(
                            record_id              NUMBER
                            ,transaction_id        NUMBER
                            ,expenditure_item_id   NUMBER
                            ,expenditure_type_id   NUMBER
							,txn_intf_id1          NUMBER
							,txn_intf_id2          NUMBER
                            ,status                VARCHAR2 (25)
                            ,error_msg             VARCHAR2 (2500)
                            ,creation_date         TIMESTAMP
                            ,created_by            VARCHAR2 (250)
                            ,last_updated_date     TIMESTAMP
                            ,last_updated_by       VARCHAR2 (250)
                	        ) TABLESPACE "XX_FUSION_CUSTOM_DATA"';
   END IF;
					 
   DBMS_OUTPUT.put_line (v_table_name || ' table created successfully.');

 EXCEPTION

 WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE (   'Error while creating '
                            || v_table_name
                            || ' table. '
                            || SQLCODE
                            || ' '
                            || SUBSTR (SQLERRM, 1, 250)
                           );
END;
/