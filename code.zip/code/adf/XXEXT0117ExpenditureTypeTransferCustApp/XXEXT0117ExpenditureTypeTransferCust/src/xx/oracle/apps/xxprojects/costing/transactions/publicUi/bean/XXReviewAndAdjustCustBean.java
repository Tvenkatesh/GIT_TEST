package xx.oracle.apps.xxprojects.costing.transactions.publicUi.bean;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.ResourceBundle;

import java.util.logging.Level;

import javax.el.ELContext;
import javax.el.ExpressionFactory;
import javax.el.ValueExpression;

import javax.faces.application.Application;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;
import oracle.adf.view.rich.component.rich.RichPopup;
import oracle.adf.view.rich.component.rich.input.RichInputComboboxListOfValues;
import oracle.adf.view.rich.component.rich.input.RichSelectOneChoice;
import oracle.adf.view.rich.component.rich.output.RichOutputText;
import oracle.adf.view.rich.context.AdfFacesContext;
import oracle.adf.view.rich.event.DialogEvent;

import oracle.apps.fnd.applcore.log.AppsLogger;
import oracle.apps.projects.costing.transactions.publicUi.bean.AdjustRegionsBean;
import oracle.apps.projects.costing.transactions.publicUi.bean.ReviewAndAdjustBean;
import oracle.apps.projects.costing.transactions.publicUi.common.ADFUtil;

import oracle.binding.BindingContainer;
import oracle.binding.OperationBinding;

import oracle.javatools.resourcebundle.BundleFactory;

import oracle.jbo.Key;
import oracle.jbo.Row;
import oracle.jbo.RowSetIterator;
import oracle.jbo.ViewCriteria;
import oracle.jbo.ViewObject;

import org.apache.myfaces.trinidad.model.RowKeySet;
import org.apache.myfaces.trinidad.util.ComponentReference;
//Added for Ext0320
import org.apache.myfaces.trinidad.render.ExtendedRenderKitService;
import org.apache.myfaces.trinidad.util.Service;


/**
 * This is a customized bean to peform Expenditure Type Transfer Actions
 */
public class XXReviewAndAdjustCustBean implements Serializable {
    private ComponentReference<RichInputComboboxListOfValues> newExpTypeId;
    private ComponentReference<RichPopup> confoMsgPopup;
    private DCIteratorBinding iter;
    private static String adjustmentType;
    private String headerText;
    private Boolean eiRecordSelected;
    private Boolean isPrebooked;
    private Boolean isPrebookedInEditPage;
    private Map prjMap = new HashMap(1);
    private String resultMsg;
    private ComponentReference<RichPopup> resultMsgPopup;
    private ComponentReference<RichSelectOneChoice> expenditureItemList;
    //START:: EXT0104 and EXT0110 variables
    private DCIteratorBinding iterBind;
    private ComponentReference<RichPopup> confMsgPopup;
    private String updateStatus;
    private String selectionMessage;
    private String transactionStatus;
    private String ownApproval;
    private String internalDelivery;
    private String expItemComment;
    private String currExpItemId;
    private Map resultMap = new HashMap();
    private ComponentReference<RichOutputText> expenditureItemId;
    //END:: EXT0104 and EXT0110 variables

    //Start EXT0320 variables
    private ComponentReference<RichPopup> invoiceMsgPopup;
    private String strImageMessage;
    private Properties reportParameters = new Properties();
    private RichPopup ebfoPreviewPopUp;
    private final String BILLING_WORKBENCH = "BW";
    //End EXT0320 variables

    public XXReviewAndAdjustCustBean() {
        super();
    }

    /**
     * This method is to capture the selected records details and navigate to Expenditure Type Transfer screen
     * @return
     */
    public String transferExpenditureType() {
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this, "transferExpenditureType::Start()",
                             AppsLogger.SEVERE);
        }
        ReviewAndAdjustBean reviewAndAdjustBean =
            getReviewAndAdjustBeanInstance();
        setAdjustmentType("TRANSFER_EXPENDITURE_TYPE");
        FacesContext fctx = FacesContext.getCurrentInstance();
        ELContext elctx = fctx.getELContext();
        Application appl = fctx.getApplication();
        ExpressionFactory elf = appl.getExpressionFactory();
        BindingContainer bindings =
            (BindingContainer)elf.createValueExpression(elctx, "#{bindings}",
                                                        BindingContainer.class).getValue(elctx);
        RowKeySet rowKeySet =
            reviewAndAdjustBean.getEiTable().getSelectedRowKeys();
        Iterator itemRows = rowKeySet.iterator();
        List selectedRowKeys = new ArrayList();
        int rowCount = rowKeySet.size();
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this,
                             "transferExpenditureType::rowCount1=" + rowCount,
                             AppsLogger.SEVERE);
        }

        if (rowCount == 0)
            return null; //If User won't select any Expenditure Item, Skip to perform action.
        while (itemRows.hasNext()) {
            List rowKeyList = (List)itemRows.next();
            Key key = (Key)rowKeyList.get(0);
            selectedRowKeys.add(key);
        }
        OperationBinding opAdjust =
            bindings.getOperationBinding("ValidateAdjustAPI");
        Map map = opAdjust.getParamsMap();
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this,
                             "transferExpenditureType::selectedRowKeys=" +
                             selectedRowKeys, AppsLogger.SEVERE);
        }
        map.put("rowKeySet", selectedRowKeys);
        map.put("AdjustmentType", getAdjustmentType());
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this, "transferExpenditureType::map2=" + map,
                             AppsLogger.SEVERE);
        }
        String rejectionCode = (String)opAdjust.execute();
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this,
                             "transferExpenditureType::rejectionCode=" + rejectionCode,
                             AppsLogger.SEVERE);
        }
        this.iter =
                ADFUtil.getBindingIterator("ProjectExpenditureItem1Iterator");
        itemRows = rowKeySet.iterator();
        List selectedeiIds = new ArrayList();
        List selRecDetails = new ArrayList();
        rowCount = rowKeySet.size();
        Long eiId = null;
        while (itemRows.hasNext()) {
            Map selRec = new HashMap();
            List rowKeyList = (List)itemRows.next();
            Key key = (Key)rowKeyList.get(0);
            eiId =
(Long)this.iter.getViewObject().getRow(key).getAttribute("ExpenditureItemId");
            if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                AppsLogger.write(this, "transferExpenditureType::eiId=" + eiId,
                                 AppsLogger.SEVERE);
            }
            selectedeiIds.add(eiId);
            selRec.put("projectName",
                       this.iter.getViewObject().getRow(key).getAttribute("Name").toString());
            Long selProjectId =
                (Long)this.iter.getViewObject().getRow(key).getAttribute("ProjectId");
            if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                AppsLogger.write(this,
                                 "transferExpenditureType::projectId=" + selProjectId,
                                 AppsLogger.SEVERE);
            }
            selRec.put("projectId", selProjectId);
            selRec.put("taskName",
                       this.iter.getViewObject().getRow(key).getAttribute("TaskName").toString());
            selRec.put("quantity",
                       this.iter.getViewObject().getRow(key).getAttribute("Quantity").toString());
            selRec.put("unitsOfMeasure",
                       this.iter.getViewObject().getRow(key).getAttribute("UnitOfMeasure").toString());
            selRec.put("billable",
                       this.iter.getViewObject().getRow(key).getAttribute("BillableFlag").toString());
            selRec.put("capitalizable",
                       this.iter.getViewObject().getRow(key).getAttribute("CapitalizableFlag").toString());
            selRec.put("holdInvoice",
                       this.iter.getViewObject().getRow(key).getAttribute("BillHoldFlag").toString());
            selRec.put("holdRevenue",
                       this.iter.getViewObject().getRow(key).getAttribute("RevenueHoldFlag").toString());
            if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                AppsLogger.write(this,
                                 "transferExpenditureType::selRec=" + selRec,
                                 AppsLogger.SEVERE);
            }

            selRecDetails.add(selRec);
        }
        ADFUtil.setEL("#{requestScope.adjustType}",
                      ADFUtil.evaluateEL("#{'TRANSFER_EXPENDITURE_TYPE'}"));
        ADFUtil.setEL("#{requestScope.rowKeyList}", selectedeiIds);
        ADFUtil.setEL("#{requestScope.selRecDetails}", selRecDetails);
        ADFUtil.setEL("#{requestScope.querCode}", null);
        ADFUtil.setEL("#{requestScope.rowKeySize}",
                      Integer.valueOf(selectedeiIds.size()));
        if (rejectionCode == null) {
            return "ependitureTypeTransfer";
        }
        OperationBinding throwException =
            bindings.getOperationBinding("throwEIRejection");
        Map mapR = null;
        mapR = throwException.getParamsMap();
        mapR.put("rejectionCode", rejectionCode);
        throwException.execute();
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this, "transferExpenditureType::Finish()",
                             AppsLogger.SEVERE);
        }
        return null;
    }

    /**
     * This method to get the seeded bean instance (ReviewAndAdjustBean).
     * @return
     */
    public ReviewAndAdjustBean getReviewAndAdjustBeanInstance() {
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this, "getReviewAndAdjustBeanInstance::Start()",
                             AppsLogger.SEVERE);
        }
        FacesContext fctx = FacesContext.getCurrentInstance();
        Application application = fctx.getApplication();
        ExpressionFactory expressionFactory =
            application.getExpressionFactory();
        ELContext context = fctx.getELContext();
        ValueExpression createValueExpression =
            expressionFactory.createValueExpression(context,
                                                    "#{backingBeanScope.ReviewAndAdjustBean}",
                                                    ReviewAndAdjustBean.class);
        ReviewAndAdjustBean beanInstance =
            (ReviewAndAdjustBean)createValueExpression.getValue(context);
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this, "getReviewAndAdjustBeanInstance::Finish()",
                             AppsLogger.SEVERE);
        }
        return beanInstance;
    }

    /**
     * This method to get the seeded bean instance (AdjustRegionsBean).
     * @return
     */
    public AdjustRegionsBean getAdjustRegionsBeanInstance() {
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this, "getAdjustRegionsBeanInstance::Start()",
                             AppsLogger.SEVERE);
        }
        FacesContext fctx = FacesContext.getCurrentInstance();
        Application application = fctx.getApplication();
        ExpressionFactory expressionFactory =
            application.getExpressionFactory();
        ELContext context = fctx.getELContext();
        ValueExpression createValueExpression =
            expressionFactory.createValueExpression(context,
                                                    "#{requestScope.AdjustRegionsBean}",
                                                    AdjustRegionsBean.class);
        AdjustRegionsBean beanInstance =
            (AdjustRegionsBean)createValueExpression.getValue(context);
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this, "getAdjustRegionsBeanInstance::Finish()",
                             AppsLogger.SEVERE);
        }
        return beanInstance;
    }

    /**
     * This function to check Mandatory fields and show the confirmation popup.
     * @param actionEvent
     */
    public void insertRecord(ActionEvent actionEvent) {
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this, "insertRecord ::Start()",
                             AppsLogger.SEVERE);
        }
        ResourceBundle pageResBundle = getExpenditureTypeResourceBundle();
        String targetExpType = this.getNewExpTypeId().getValue().toString();
        AppsLogger.write(this, "insertRecord::targetExpType=" + targetExpType,
                         AppsLogger.SEVERE);
        List eiList = (List)ADFUtil.evaluateEL("#{pageFlowScope.rowKeyList}");
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this,
                             "insertRecord::targetExpType=" + targetExpType,
                             AppsLogger.SEVERE);
        }
        ADFContext cntxt = ADFContext.getCurrent();
        // if user has selected a expenditure item type.
        if (targetExpType != null && targetExpType.length() > 0) {
            DCBindingContainer bindings =
                (DCBindingContainer)BindingContext.getCurrent().getCurrentBindingsEntry();
            //To check selected Expenditure Type is Salary Expenditure Tyep or not.
            OperationBinding salOperBind =
                (OperationBinding)bindings.getOperationBinding("salaryExpTypeCheck");
            salOperBind.getParamsMap().put("newExpTypeId", targetExpType);
            salOperBind.getParamsMap().put("selExpItems", eiList);
            salOperBind.execute();
            if (salOperBind.getResult() != null &&
                salOperBind.getResult().toString().equalsIgnoreCase("TRUE")) {
                String respMsg =
                    pageResBundle.getString("SAL_EXPENDITURE_TYPE");
                RichPopup.PopupHints hints = new RichPopup.PopupHints();
                this.setResultMsg(respMsg);
                this.getResultMsgPopup().show(hints);
            } else {
                 OperationBinding oper =
                    (OperationBinding)bindings.getOperationBinding("selectedExpenditureCheck"); 
                if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                    AppsLogger.write(this, "insertRecord::eiList    ....=" + eiList,
                                     AppsLogger.SEVERE);
                }
                oper.getParamsMap().put("selRecEiIds", eiList);
                oper.execute();
                if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                    AppsLogger.write(this,
                                     "##After Execute::selectedExpenditureCheck 77777################",
                                     AppsLogger.SEVERE);
                }
               /*  if (oper.getResult() != null &&
                    oper.getResult().toString().equalsIgnoreCase("TRUE")) {
                    if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                        AppsLogger.write(this, "insertRecord::INSIDE IF",
                                         AppsLogger.SEVERE);
                    }
                    String respMsg = pageResBundle.getString("SUBMIT_PENDING");
                    RichPopup.PopupHints hints = new RichPopup.PopupHints();
                    this.setResultMsg(respMsg);
                    this.getResultMsgPopup().show(hints);
                } else */
                if ((((String)cntxt.getPageFlowScope().get("EXT0117ExpenditureTypeName")) !=
                            null)) {
                    if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                        AppsLogger.write(this, "insertRecord:: INSIDE ELSE IF",
                                         AppsLogger.SEVERE);
                    }
                    //same expenditure type then error message
                    if (((String)cntxt.getPageFlowScope().get("EXT0117ExpenditureTypeName")).equals(targetExpType)) {
                        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                            AppsLogger.write(this,
                                             "insertRecord:: Dispay Error Message If Type Is Same",
                                             AppsLogger.SEVERE);
                        }
                        FacesMessage newNewExpenditureType =
                            new FacesMessage(FacesMessage.SEVERITY_ERROR, null,
                                             pageResBundle.getString("EXPTYPE_APPROPRIATE"));
                        FacesContext.getCurrentInstance().addMessage("Error Message",
                                                                     newNewExpenditureType);
                    } else {
                        // For one row selection, dispalying conformation dialog.
                        UIComponent source =
                            (UIComponent)actionEvent.getSource();
                        RichPopup.PopupHints hints =
                            new RichPopup.PopupHints();
                        // Display a popup for confirmation.
                        hints.add(RichPopup.PopupHints.HintTypes.HINT_ALIGN_ID,
                                  source).add(RichPopup.PopupHints.HintTypes.HINT_LAUNCH_ID,
                                              source).add(RichPopup.PopupHints.HintTypes.HINT_ALIGN,
                                                          RichPopup.PopupHints.AlignTypes.ALIGN_AFTER_START);
                        this.getConfoMsgPopup().show(hints);
                    }
                } else {
                    UIComponent source = (UIComponent)actionEvent.getSource();
                    RichPopup.PopupHints hints = new RichPopup.PopupHints();
                    // Display a popup for confirmation.
                    hints.add(RichPopup.PopupHints.HintTypes.HINT_ALIGN_ID,
                              source).add(RichPopup.PopupHints.HintTypes.HINT_LAUNCH_ID,
                                          source).add(RichPopup.PopupHints.HintTypes.HINT_ALIGN,
                                                      RichPopup.PopupHints.AlignTypes.ALIGN_AFTER_START);
                    this.getConfoMsgPopup().show(hints);
                }
            }
        } else {
            // No expenditure item type then error message.
            FacesMessage newNewExpenditureType =
                new FacesMessage(FacesMessage.SEVERITY_ERROR, null,
                                 pageResBundle.getString("EXPTYPE_MANDATORY"));

            FacesContext.getCurrentInstance().addMessage("Error Message",
                                                         newNewExpenditureType);
        }
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this, "insertRecord::Finish()",
                             AppsLogger.SEVERE);
        }
    }

    /**
     * This method to transfer One Expenditure Type to another Expenditure Type
     * @param dialogEvent
     */
    public void insert(DialogEvent dialogEvent) {
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this, "insert::Start()  ", AppsLogger.SEVERE);
        }
        ResourceBundle pageResBundle = getExpenditureTypeResourceBundle();
        if (dialogEvent.getOutcome() == DialogEvent.Outcome.ok) {
            if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                AppsLogger.write(this, "insert::OK", AppsLogger.SEVERE);
            }
            List eiList =
                (List)ADFUtil.evaluateEL("#{pageFlowScope.rowKeyList}");
            if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                AppsLogger.write(this, "insert::eiList=" + eiList,
                                 AppsLogger.SEVERE);
            }
            String targetExpType =
                this.getNewExpTypeId().getValue().toString();
            AppsLogger.write(this,
                             "insertRecord::targetExpType=" + targetExpType,
                             AppsLogger.SEVERE);
            DCBindingContainer bindings =
                (DCBindingContainer)BindingContext.getCurrent().getCurrentBindingsEntry();
            OperationBinding oper =
                (OperationBinding)bindings.getOperationBinding("expenditureTypeTransfer");

            oper.getParamsMap().put("newExpTypeId", targetExpType);
            oper.getParamsMap().put("selExpLineItemIds", eiList);
            oper.execute();

            List resultLst = (List)oper.getResult();
            if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                AppsLogger.write(this,
                                 "insert::resultLst.get(0)=" + resultLst.get(0),
                                 AppsLogger.SEVERE);
                AppsLogger.write(this,
                                 "insert::resultLst.get(1)=" + resultLst.get(1),
                                 AppsLogger.SEVERE);
            }
            if (resultLst != null) {
                if (resultLst.get(0) != null) {
                    if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                        AppsLogger.write(this,
                                         "insert::Job ID::" + resultLst.get(0),
                                         AppsLogger.SEVERE);
                    }
                    RichPopup.PopupHints hints = new RichPopup.PopupHints();
                    this.setResultMsg(pageResBundle.getString("EXP_TYPE_TRANSFER_SUCCESS") +
                                      resultLst.get(0).toString());
                    this.getResultMsgPopup().show(hints);
                } else {
                    if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                        AppsLogger.write(this,
                                         "insert::Error Message::" + resultLst.get(1),
                                         AppsLogger.SEVERE);
                    }
                    RichPopup.PopupHints hints = new RichPopup.PopupHints();
                    this.setResultMsg(resultLst.get(1).toString());
                    this.getResultMsgPopup().show(hints);
                }
            } else {
                AppsLogger.write(this,
                                 "insert::expenditureTypeTransfer returns null",
                                 AppsLogger.SEVERE);
                RichPopup.PopupHints hints = new RichPopup.PopupHints();
                this.setResultMsg(pageResBundle.getString("CONTACT_SYSTEMADMIN"));
                this.getResultMsgPopup().show(hints);
            }
        } else {
            if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                AppsLogger.write(this,
                                 "insert::CANCEL:: Not Going to insert Record",
                                 AppsLogger.SEVERE);
            }
        }
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this, "insert::Finish()", AppsLogger.SEVERE);
        }
    }

    public static void setAdjustmentType(String adjustmentType) {
        XXReviewAndAdjustCustBean.adjustmentType = adjustmentType;
    }

    public static String getAdjustmentType() {
        return adjustmentType;
    }

    public void setHeaderText(String headerText) {
        this.headerText = headerText;
    }

    /**
     * This method to set the header test, if user selected only one record
     * @return
     */
    public String getHeaderText() {
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this, "getHeaderText:Start()", AppsLogger.SEVERE);
        }
        List eiList = (List)ADFUtil.evaluateEL("#{pageFlowScope.rowKeyList}");
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this, "getHeaderText::eiList=" + eiList,
                             AppsLogger.SEVERE);
        }
        String resultText = "";
        if (eiList.size() == 1) {
            resultText = ": " + eiList.get(0).toString();
        }
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this, "getHeaderText::resultText=" + resultText,
                             AppsLogger.SEVERE);
        }
        return resultText;
    }

    /**
     * To load the resource bundle file
     * @return
     */
    public ResourceBundle getExpenditureTypeResourceBundle() {

        ResourceBundle pageResBundle;
        Locale locale =
            FacesContext.getCurrentInstance().getViewRoot().getLocale();
        pageResBundle =
                BundleFactory.getBundle("xx.oracle.apps.xxprojects.costing.transactions.bundle.XXExpenditureTypeTransferBundle",
                                        locale);
        return pageResBundle;
    }

    public void setPrjMap(Map prjMap) {
        this.prjMap = prjMap;
    }

    public Map getPrjMap() {
        return prjMap;
    }

    public void setConfoMsgPopup(RichPopup confoMsgPopup) {
        if (confoMsgPopup != null) {
            this.confoMsgPopup =
                    ComponentReference.newUIComponentReference(confoMsgPopup);
        }
    }

    public RichPopup getConfoMsgPopup() {
        return confoMsgPopup == null ? null : confoMsgPopup.getComponent();
    }

    public void setNewExpTypeId(RichInputComboboxListOfValues newExpTypeId) {

        if (newExpTypeId != null) {
            this.newExpTypeId =
                    ComponentReference.newUIComponentReference(newExpTypeId);
        }
    }

    public RichInputComboboxListOfValues getNewExpTypeId() {
        return newExpTypeId == null ? null : newExpTypeId.getComponent();
    }

    public void setEiRecordSelected(Boolean eiRecordSelected) {
        this.eiRecordSelected = eiRecordSelected;
    }

    /**
     * This method to Enable and Disable Expenditure Type Transfer hyper link
     * @return
     */
    public Boolean getEiRecordSelected() {
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this, "getEiRecordSelected::Start()",
                             AppsLogger.SEVERE);
        }
        boolean returnStatus = false;
        List selRecEiIds = selectedRecordsEiId();

        if (selRecEiIds.size() > 0) {
            DCBindingContainer bindings =
                (DCBindingContainer)BindingContext.getCurrent().getCurrentBindingsEntry();
            OperationBinding oper =
                (OperationBinding)bindings.getOperationBinding("selectedExpenditureCheck");
            if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                AppsLogger.write(this,
                                 "getEiRecordSelected::selRecEiId2s=" + selRecEiIds,
                                 AppsLogger.SEVERE);
            }
            oper.getParamsMap().put("selRecEiIds", selRecEiIds);


            oper.execute();

            String result = "false";

            if (oper.getResult() != null) {
                result = oper.getResult().toString();
                if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                    AppsLogger.write(this,
                                     "getEiRecordSelected::result=" + result,
                                     AppsLogger.SEVERE);
                }
                if (result.equalsIgnoreCase("true")) {
                    returnStatus = true;
                } else {
                    returnStatus = false;
                }
            }
        }
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this,
                             "getEiRecordSelected::Finish()=" + returnStatus,
                             AppsLogger.SEVERE);
        }
        return returnStatus;


    }

    public void setResultMsg(String resultMsg) {
        this.resultMsg = resultMsg;
    }

    public String getResultMsg() {
        return resultMsg;
    }

    public void setResultMsgPopup(RichPopup resultMsgPopup) {
        if (resultMsgPopup != null) {
            this.resultMsgPopup =
                    ComponentReference.newUIComponentReference(resultMsgPopup);
        }
    }

    public RichPopup getResultMsgPopup() {
        return resultMsgPopup == null ? null : resultMsgPopup.getComponent();
    }

    public void setExpenditureItemList(RichSelectOneChoice expenditureItemList) {
        if (expenditureItemList != null) {
            this.expenditureItemList =
                    ComponentReference.newUIComponentReference(expenditureItemList);
        }
    }

    public RichSelectOneChoice getExpenditureItemList() {
        return expenditureItemList == null ? null :
               expenditureItemList.getComponent();
    }

    /**
     * This method to get the selected Expenditure Item Type to transfer
     * @return
     */
    public long getSelectedExpenditureItemType() {
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this, "getSelectedExpenditureItemType::Start()",
                             AppsLogger.SEVERE);
        }
        BindingContext bc = BindingContext.getCurrent();
        DCBindingContainer binding =
            (DCBindingContainer)bc.getCurrentBindingsEntry();
        DCIteratorBinding selectedExpTypeVO =
            binding.findIteratorBinding("XXExpenditureTypesVOIterator");
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this,
                             "getSelectedExpenditureItemType:ROW=" + selectedExpTypeVO.getCurrentRow(),
                             AppsLogger.SEVERE);
        }

        Row row = selectedExpTypeVO.getCurrentRow();
        Long selectedExpenditureTypeId = null;

        if (row.getAttribute("ExpenditureTypeId") != null) {
            selectedExpenditureTypeId =
                    (Long)row.getAttribute("ExpenditureTypeId");
        }
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this,
                             "getSelectedExpenditureItemType::selectedExpenditureTypeId=" +
                             selectedExpenditureTypeId, AppsLogger.SEVERE);
            AppsLogger.write(this, "getSelectedExpenditureItemType::Finish()",
                             AppsLogger.SEVERE);
        }
        return selectedExpenditureTypeId;
    }

    /**
     * This method to capture selected Expenditure Items.
     * @return
     */
    public List selectedRecordsEiId() {
        ReviewAndAdjustBean reviewAndAdjustBean =
            getReviewAndAdjustBeanInstance();
        RowKeySet rowKeySet =
            reviewAndAdjustBean.getEiTable().getSelectedRowKeys();
        List selRecEiIds = new ArrayList();

        if (rowKeySet != null && rowKeySet.getSize() > 0) {
            if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                AppsLogger.write(this,
                                 "selectedRecordsEiId::rowKeySet=" + rowKeySet,
                                 AppsLogger.SEVERE);
                AppsLogger.write(this,
                                 "selectedRecordsEiId::ADFUtil.getBindingIterator=" +
                                 ADFUtil.getBindingIterator("ProjectExpenditureItem1Iterator"),
                                 AppsLogger.SEVERE);
            }
            this.iter =
                    ADFUtil.getBindingIterator("ProjectExpenditureItem1Iterator");
            if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                AppsLogger.write(this,
                                 "selectedRecordsEiId::this.iter.getViewObject().getRowCount()=" +
                                 this.iter.getViewObject().getRowCount(),
                                 AppsLogger.SEVERE);
            }
            if (this.iter != null &&
                this.iter.getViewObject().getRowCount() > 0) {
                Iterator itemRows = rowKeySet.iterator();


                while (itemRows.hasNext()) {
                    Long eiId = null;
                    List rowKeyList = (List)itemRows.next();
                    Key key = (Key)rowKeyList.get(0);
                    if (this.iter.getViewObject().getRow(key) != null) {
                        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                            AppsLogger.write(this,
                                             "selectedRecordsEiId:Inside IF",
                                             AppsLogger.SEVERE);
                        }
                        eiId =
(Long)this.iter.getViewObject().getRow(key).getAttribute("ExpenditureItemId");
                        selRecEiIds.add(eiId);
                    } else {
                        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                            AppsLogger.write(this,
                                             "selectedRecordsEiId:Inside ELSE",
                                             AppsLogger.SEVERE);
                        }
                    }
                }
                if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                    AppsLogger.write(this,
                                     "selectedRecordsEiId::selRecEiIds=" +
                                     selRecEiIds, AppsLogger.SEVERE);
                }
            }
        }
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this,
                             "selectedRecordsEiId::selRecEiIds=" + selRecEiIds,
                             AppsLogger.SEVERE);
        }
        return selRecEiIds;
    }

    public void setIsPrebooked(Boolean isPrebooked) {
        this.isPrebooked = isPrebooked;
    }

    /**
     * This method calls and check the transfer & split link are enable or not from search result page based on Pre-booked status.
     * @return
     */
    public Boolean getIsPrebooked() {
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this, "getIsPrebooked::Start()",
                             AppsLogger.SEVERE);
        }
        boolean returnStatus = false;
        List selRecEiIds = selectedRecordsEiId();
        returnStatus = preBookCall(selRecEiIds);
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this, "getIsPrebooked::Finish()=" + returnStatus,
                             AppsLogger.SEVERE);
        }
        return returnStatus;

    }

    /**
     * This method to interact with AMImpl and check weather the selected expenditure's are Pre-booked Expenditure Items or not.
     * @param selRecEiIds
     * @return
     */
    public Boolean preBookCall(List selRecEiIds) {
        if (selRecEiIds.size() > 0) {
            DCBindingContainer bindings =
                (DCBindingContainer)BindingContext.getCurrent().getCurrentBindingsEntry();
            OperationBinding oper =
                (OperationBinding)bindings.getOperationBinding("preBookCheck");
            if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                AppsLogger.write(this,
                                 "getEiRecordSelected::selRecEiId2s=" + selRecEiIds,
                                 AppsLogger.SEVERE);
            }
            oper.getParamsMap().put("selRecEiIds", selRecEiIds);
            oper.execute();
            String result = "false";
            if (oper.getResult() != null) {
                result = oper.getResult().toString();
                if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                    AppsLogger.write(this,
                                     "getEiRecordSelected::result=" + result,
                                     AppsLogger.SEVERE);
                }
                if (result.equalsIgnoreCase("true")) {
                    return true;
                } else {
                    return false;
                }
            }
        }
        return false;
    }

    public void setIsPrebookedInEditPage(Boolean isPrebookedInEditPage) {
        this.isPrebookedInEditPage = isPrebookedInEditPage;
    }

    /**
     * This method calls and check the transfer & split link are enable or not in Expenditure Item edit page based on Pre-booked status.
     * @return
     */
    public Boolean getIsPrebookedInEditPage() {
        String expItemId =
            ADFUtil.evaluateEL("#{bindings.ExpenditureItemId}").toString();
        boolean returnStatus = false;
        List selRecEiIds = new ArrayList();
        selRecEiIds.add(expItemId);
        returnStatus = preBookCall(selRecEiIds);
        return returnStatus;
    }

    //START:: EXT0104 and EXT0110 Methods

    /**
     * This function call on click of Own Approval button and check the selected expenditure items contain any pre-booked are there.
     * If all are not pre-booked then it opens the confirmation popup.
     * @param actionEvent
     */
    public void ownApprovalActionListener(ActionEvent actionEvent) {
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this, "ownApprovalActionListener::Start()",
                             AppsLogger.SEVERE);
        }
        FacesContext fctx = FacesContext.getCurrentInstance();
        ELContext elctx = fctx.getELContext();
        Application appl = fctx.getApplication();
        ExpressionFactory elf = appl.getExpressionFactory();
        BindingContainer bindings =
            (BindingContainer)elf.createValueExpression(elctx, "#{bindings}",
                                                        BindingContainer.class).getValue(elctx);
        ResourceBundle pageResBundle = getExpenditureTypeResourceBundle();
        List expItemsLst = selExpItems();
        if (expItemsLst != null && expItemsLst.size() > 0) {
            if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                AppsLogger.write(this,
                                 "ownApprovalActionListener::selEidList.size()::" +
                                 expItemsLst.size(), AppsLogger.SEVERE);
            }
            //Method binding call to check the selected expenditure items are Pre-booked or not
            OperationBinding operPreBook =
                (OperationBinding)bindings.getOperationBinding("preBookCheck");
            operPreBook.getParamsMap().put("selRecEiIds", expItemsLst);
            operPreBook.execute();
            String preBookResult = operPreBook.getResult().toString();
            if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                AppsLogger.write(this,
                                 "ownApprovalActionListener::preBookResult::" +
                                 preBookResult, AppsLogger.SEVERE);
            }
            if (preBookResult.equalsIgnoreCase("false")) {
                //Method binding call to check the selected expenditure items Own Approval status
                OperationBinding operOwnApprovalChk =
                    (OperationBinding)bindings.getOperationBinding("ownApprovalStatusCheck");
                operOwnApprovalChk.getParamsMap().put("selRecEiIds",
                                                      expItemsLst);
                operOwnApprovalChk.execute();
                if (operOwnApprovalChk.getResult() != null) {
                    if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                        AppsLogger.write(this,
                                         "ownApprovalActionListener::operOwnApprovalChk::" +
                                         operOwnApprovalChk,
                                         AppsLogger.SEVERE);
                    }
                    if (operOwnApprovalChk.getResult().toString().equalsIgnoreCase("combinationSelection")) {
                        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                            AppsLogger.write(this,
                                             "ownApprovalActionListener::combinationSelection",
                                             AppsLogger.SEVERE);
                        }
                        FacesMessage errorMessage =
                            new FacesMessage(FacesMessage.SEVERITY_ERROR, null,
                                             pageResBundle.getString("COMBINATION_SELECTION"));
                        FacesContext.getCurrentInstance().addMessage("Error Message",
                                                                     errorMessage);
                    } else if (operOwnApprovalChk.getResult().toString().equalsIgnoreCase("ownApproved")) {
                        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                            AppsLogger.write(this,
                                             "ownApprovalActionListener::ownApproved",
                                             AppsLogger.SEVERE);
                        }
                        this.setSelectionMessage(pageResBundle.getString("NON_OWNAPPROVED_CONF_MSG"));
                        this.updateStatus = "N";
                        UIComponent source =
                            (UIComponent)actionEvent.getSource();
                        RichPopup.PopupHints hints =
                            new RichPopup.PopupHints();
                        // Display a popup for confirmation.
                        hints.add(RichPopup.PopupHints.HintTypes.HINT_ALIGN_ID,
                                  source).add(RichPopup.PopupHints.HintTypes.HINT_LAUNCH_ID,
                                              source).add(RichPopup.PopupHints.HintTypes.HINT_ALIGN,
                                                          RichPopup.PopupHints.AlignTypes.ALIGN_AFTER_START);
                        this.getConfMsgPopup().show(hints);
                    } else if (operOwnApprovalChk.getResult().toString().equalsIgnoreCase("nonOwnApproved")) {
                        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                            AppsLogger.write(this,
                                             "ownApprovalActionListener::nonOwnApproved",
                                             AppsLogger.SEVERE);
                        }
                        this.setSelectionMessage(pageResBundle.getString("OWNAPPROVED_CONF_MSG"));
                        this.updateStatus = "Y";
                        UIComponent source =
                            (UIComponent)actionEvent.getSource();
                        RichPopup.PopupHints hints =
                            new RichPopup.PopupHints();
                        // Display a popup for confirmation.
                        hints.add(RichPopup.PopupHints.HintTypes.HINT_ALIGN_ID,
                                  source).add(RichPopup.PopupHints.HintTypes.HINT_LAUNCH_ID,
                                              source).add(RichPopup.PopupHints.HintTypes.HINT_ALIGN,
                                                          RichPopup.PopupHints.AlignTypes.ALIGN_AFTER_START);
                        this.getConfMsgPopup().show(hints);
                    }
                } else {
                    if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                        AppsLogger.write(this,
                                         "ownApprovalActionListener::Status Update FAIL",
                                         AppsLogger.SEVERE);
                    }
                    FacesMessage errorMessage =
                        new FacesMessage(FacesMessage.SEVERITY_ERROR, null,
                                         pageResBundle.getString("APPLICATION_ERROR"));
                    FacesContext.getCurrentInstance().addMessage("Error Message",
                                                                 errorMessage);
                }
            } else {
                if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                    AppsLogger.write(this,
                                     "ownApprovalActionListener::Inside Pre Book ELSE",
                                     AppsLogger.SEVERE);
                }
                FacesMessage errorMessage =
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, null,
                                     pageResBundle.getString("PREBOOK_EXPITEMS_SELECT"));
                FacesContext.getCurrentInstance().addMessage("Error Message",
                                                             errorMessage);
            }
        } else {
            if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                AppsLogger.write(this,
                                 "ownApprovalActionListener::Inside ELSE",
                                 AppsLogger.SEVERE);
            }
            FacesMessage errorMessage =
                new FacesMessage(FacesMessage.SEVERITY_ERROR, null,
                                 pageResBundle.getString("SELECT_ONE_EXPITEM"));
            FacesContext.getCurrentInstance().addMessage("Error Message",
                                                         errorMessage);
        }
    }

    /**
     * This function calls from confirmation popup. User select yes, it will proceed for Own Approval else cancel the action.
     * @param dialogEvent
     */
    public void ownApprovalStatusUpdate(DialogEvent dialogEvent) {
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this, "ownApprovalStatusUpdate::Start()",
                             AppsLogger.SEVERE);
        }
        try {
            if ("yes".equalsIgnoreCase(dialogEvent.getOutcome().toString())) {
                if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                    AppsLogger.write(this,
                                     "ownApprovalStatusUpdate::Inside IF",
                                     AppsLogger.SEVERE);
                }
                this.getConfMsgPopup().hide();
                ResourceBundle pageResBundle =
                    getExpenditureTypeResourceBundle();
                FacesContext fctx = FacesContext.getCurrentInstance();
                ELContext elctx = fctx.getELContext();
                Application appl = fctx.getApplication();
                ExpressionFactory elf = appl.getExpressionFactory();
                BindingContainer bindings =
                    (BindingContainer)elf.createValueExpression(elctx,
                                                                "#{bindings}",
                                                                BindingContainer.class).getValue(elctx);
                //Method binding call to update the Own Approval status
                OperationBinding operOwnApproval =
                    (OperationBinding)bindings.getOperationBinding("ownApprovalStatusUpdate");
                if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                    AppsLogger.write(this,
                                     "ownApprovalStatusUpdate::selExpItems()::" +
                                     selExpItems(), AppsLogger.SEVERE);
                }
                operOwnApproval.getParamsMap().put("selRecEiIds",
                                                   selExpItems());
                operOwnApproval.getParamsMap().put("updateStatus",
                                                   this.updateStatus);
                operOwnApproval.execute();
                if (operOwnApproval.getResult() != null &&
                    operOwnApproval.getResult().toString().equalsIgnoreCase("true")) {
                    if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                        AppsLogger.write(this,
                                         "ownApprovalStatusUpdate::Status Update Result::" +
                                         operOwnApproval.getResult().toString(),
                                         AppsLogger.SEVERE);
                    }
                    ReviewAndAdjustBean reviewAndAdjustBean =
                        getSeededBeanInstance();
                    DCIteratorBinding iter =
                        ADFUtil.getBindingIterator("ProjectExpenditureItem1Iterator");
                    iter.executeQuery();
                    AdfFacesContext.getCurrentInstance().addPartialTarget(reviewAndAdjustBean.getEiTable());
                    FacesMessage inforMessage =
                        new FacesMessage(FacesMessage.SEVERITY_INFO, null,
                                         pageResBundle.getString("OWN_APPROVAL_SUCCESS_MSG"));
                    FacesContext.getCurrentInstance().addMessage("Info Message",
                                                                 inforMessage);
                } else {
                    AppsLogger.write(this,
                                     "ownApprovalStatusUpdate::Status Update FAIL",
                                     AppsLogger.SEVERE);
                    FacesMessage errorMessage =
                        new FacesMessage(FacesMessage.SEVERITY_ERROR, null,
                                         pageResBundle.getString("APPLICATION_ERROR"));
                    FacesContext.getCurrentInstance().addMessage("Error Message",
                                                                 errorMessage);
                }
            } else {
                if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                    AppsLogger.write(this,
                                     "ownApprovalStatusUpdate::CANCEL:: Not Going to update",
                                     AppsLogger.SEVERE);
                }
            }
        } catch (Exception e) {
            AppsLogger.write(this,
                             "ownApprovalStatusUpdate::Exception::" + e.getMessage(),
                             AppsLogger.SEVERE);
            e.printStackTrace();
        }
    }

    /**
     * This function to get the selected Expenditure Items
     * @return
     */
    public List selExpItems() {
        ReviewAndAdjustBean reviewAndAdjustBean = getSeededBeanInstance();

        RowKeySet rowKeySet =
            reviewAndAdjustBean.getEiTable().getSelectedRowKeys();

        int rowCount = rowKeySet.size();
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this, "selExpItems::rowCount::" + rowCount,
                             AppsLogger.SEVERE);
        }
        this.iterBind =
                ADFUtil.getBindingIterator("ProjectExpenditureItem1Iterator");
        List eiIdList = new ArrayList();
        if (this.iterBind != null &&
            this.iterBind.getViewObject().getRowCount() > 0) {
            Iterator itemRows = rowKeySet.iterator();
            while (itemRows.hasNext()) {
                Long eiId = null;
                List rowKeyList = (List)itemRows.next();
                Key key = (Key)rowKeyList.get(0);
                if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                    AppsLogger.write(this, "selExpItems::key::" + key,
                                     AppsLogger.SEVERE);
                }
                eiId =
(Long)this.iterBind.getViewObject().getRow(key).getAttribute("ExpenditureItemId");
                eiIdList.add(eiId);
            }
        }
        return eiIdList;
    }

    /**
     * This function to get the seeded bean instance of ReviewAndAdjustBean.
     * @return
     */
    public ReviewAndAdjustBean getSeededBeanInstance() {
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this, "getSeededBeanInstance::Start()",
                             AppsLogger.SEVERE);
        }
        FacesContext fctx = FacesContext.getCurrentInstance();
        Application application = fctx.getApplication();
        ExpressionFactory expressionFactory =
            application.getExpressionFactory();
        ELContext context = fctx.getELContext();
        ValueExpression createValueExpression =
            expressionFactory.createValueExpression(context,
                                                    "#{backingBeanScope.ReviewAndAdjustBean}",
                                                    ReviewAndAdjustBean.class);
        ReviewAndAdjustBean beanInstance =
            (ReviewAndAdjustBean)createValueExpression.getValue(context);
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this, "getSeededBeanInstance::Finish()",
                             AppsLogger.SEVERE);
        }
        return beanInstance;
    }

    public void setConfMsgPopup(RichPopup confMsgPopup) {
        if (confMsgPopup != null) {
            this.confMsgPopup =
                    ComponentReference.newUIComponentReference(confMsgPopup);
        }
    }

    public RichPopup getConfMsgPopup() {
        return confMsgPopup == null ? null : confMsgPopup.getComponent();
    }

    public void setSelectionMessage(String selectionMessage) {
        this.selectionMessage = selectionMessage;
    }

    public String getSelectionMessage() {
        return selectionMessage;
    }

    /**
     * This function to get the TransactionStatus, OwnApproval and InternalDelivery details to a corresponding Expenditure Item
     */
    public void getExpenditureItemDetails() {
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this, "getExpenditureItemDetails.start()",
                             AppsLogger.SEVERE);
        }
        String expItemId = null;
        expItemId = this.getExpenditureItemId().getValue().toString();
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this,
                             "getExpenditureItemDetails:expItemId::" + expItemId,
                             AppsLogger.SEVERE);
        }
        this.setCurrExpItemId(expItemId);
        if (resultMap != null && resultMap.get(expItemId) != null) {
            if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                AppsLogger.write(this, "getExpenditureItemDetails.Inside IF",
                                 AppsLogger.SEVERE);
            }
            Map valuesMap = new HashMap();
            valuesMap = (HashMap)resultMap.get(expItemId);

            this.setTransactionStatus(valuesMap.get("TransactionStatus") !=
                                      null ?
                                      valuesMap.get("TransactionStatus").toString() :
                                      null);
            this.setOwnApproval(valuesMap.get("OwnApproval") != null ?
                                valuesMap.get("OwnApproval").toString() :
                                null);
            this.setInternalDelivery(valuesMap.get("InternalDelivery") !=
                                     null ?
                                     valuesMap.get("InternalDelivery").toString() :
                                     null);
            this.setExpItemComment(valuesMap.get("ExpItemComment") != null ?
                                   valuesMap.get("ExpItemComment").toString() :
                                   null);
        } else {
            if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                AppsLogger.write(this, "getExpenditureItemDetails.Inside ELSE",
                                 AppsLogger.SEVERE);
            }
            FacesContext fctx = FacesContext.getCurrentInstance();
            ELContext elctx = fctx.getELContext();
            Application appl = fctx.getApplication();
            ExpressionFactory elf = appl.getExpressionFactory();
            BindingContainer bindings =
                (BindingContainer)elf.createValueExpression(elctx,
                                                            "#{bindings}",
                                                            BindingContainer.class).getValue(elctx);
            OperationBinding oprExpItemDetail =
                (OperationBinding)bindings.getOperationBinding("expItemOwnApprovalDetails");
            Map map = oprExpItemDetail.getParamsMap();
            map.put("expItemId", expItemId);
            oprExpItemDetail.execute();
            if (oprExpItemDetail.getResult() != null) {
                Map<String, Map> resMap =
                    (HashMap<String, Map>)oprExpItemDetail.getResult();
                Map resValues = resMap.get(expItemId);
                this.setTransactionStatus(resValues.get("TransactionStatus") !=
                                          null ?
                                          resValues.get("TransactionStatus").toString() :
                                          null);
                this.setOwnApproval(resValues.get("OwnApproval") != null ?
                                    resValues.get("OwnApproval").toString() :
                                    null);
                this.setInternalDelivery(resValues.get("InternalDelivery") !=
                                         null ?
                                         resValues.get("InternalDelivery").toString() :
                                         null);
                this.setExpItemComment(resValues.get("ExpItemComment") !=
                                       null ?
                                       resValues.get("ExpItemComment").toString() :
                                       null);
                Map valuesMap = new HashMap();
                valuesMap.put("TransactionStatus",
                              resValues.get("TransactionStatus") != null ?
                              resValues.get("TransactionStatus").toString() :
                              null);
                valuesMap.put("OwnApproval",
                              resValues.get("OwnApproval") != null ?
                              resValues.get("OwnApproval").toString() : null);
                valuesMap.put("InternalDelivery",
                              resValues.get("InternalDelivery") != null ?
                              resValues.get("InternalDelivery").toString() :
                              null);
                valuesMap.put("ExpItemComment",
                              resValues.get("ExpItemComment") != null ?
                              resValues.get("ExpItemComment").toString() :
                              null);
                resultMap.put(expItemId, valuesMap);
            }
        }
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this, "getExpenditureItemDetails.end()",
                             AppsLogger.SEVERE);
        }
    }

    public void setTransactionStatus(String transactionStatus) {
        this.transactionStatus = transactionStatus;
    }

    public String getTransactionStatus() {
        getExpenditureItemDetails();
        Map valuesMap = new HashMap();
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this,
                             "getTransactionStatus::this.getCurrExpItemId()::" +
                             this.getCurrExpItemId(), AppsLogger.SEVERE);
        }
        valuesMap = (HashMap)resultMap.get(this.getCurrExpItemId());
        {
            AppsLogger.write(this,
                             "getTransactionStatus::valuesMap::" + valuesMap,
                             AppsLogger.SEVERE);
        }
        return (valuesMap.get("TransactionStatus") != null ?
                valuesMap.get("TransactionStatus").toString() : null);

    }

    public void setOwnApproval(String ownApproval) {
        this.ownApproval = ownApproval;
    }

    public String getOwnApproval() {
        getExpenditureItemDetails();
        Map valuesMap = new HashMap();
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this,
                             "getOwnApproval::this.getCurrExpItemId()::" +
                             this.getCurrExpItemId(), AppsLogger.SEVERE);
        }
        valuesMap = (HashMap)resultMap.get(this.getCurrExpItemId());
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this, "getOwnApproval::valuesMap::" + valuesMap,
                             AppsLogger.SEVERE);
        }
        return (valuesMap.get("OwnApproval") != null ?
                valuesMap.get("OwnApproval").toString() : null);

    }

    public void setInternalDelivery(String internalDelivery) {
        this.internalDelivery = internalDelivery;
    }

    public String getInternalDelivery() {
        getExpenditureItemDetails();
        Map valuesMap = new HashMap();
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this,
                             "getInternalDelivery::this.getCurrExpItemId()::" +
                             this.getCurrExpItemId(), AppsLogger.SEVERE);
        }
        valuesMap = (HashMap)resultMap.get(this.getCurrExpItemId());
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this,
                             "getInternalDelivery::valuesMap::" + valuesMap,
                             AppsLogger.SEVERE);
        }
        return (valuesMap.get("InternalDelivery") != null ?
                valuesMap.get("InternalDelivery").toString() : null);

    }

    public void setExpItemComment(String expItemComment) {
        this.expItemComment = expItemComment;
    }

    public String getExpItemComment() {
        getExpenditureItemDetails();
        Map valuesMap = new HashMap();
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this,
                             "getExpItemComment::this.getCurrExpItemId()::" +
                             this.getCurrExpItemId(), AppsLogger.SEVERE);
        }
        valuesMap = (HashMap)resultMap.get(this.getCurrExpItemId());
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this,
                             "getExpItemComment::valuesMap::" + valuesMap,
                             AppsLogger.SEVERE);
        }
        return (valuesMap.get("ExpItemComment") != null ?
                valuesMap.get("ExpItemComment").toString() : null);

    }

    public void customHandleMassAdjustment(ActionEvent actionEvent) {
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this, "customHandleMassAdjustment::start()",
                             AppsLogger.SEVERE);
        }
        ResourceBundle pageResBundle = getExpenditureTypeResourceBundle();
        DCBindingContainer bindings =
            (DCBindingContainer)BindingContext.getCurrent().getCurrentBindingsEntry();
        DCIteratorBinding dcIteratorBindings =
            bindings.findIteratorBinding("ProjectExpenditureItem1Iterator");
        List expItemsLst = new ArrayList();
        ViewObject expItemVO = dcIteratorBindings.getViewObject();
        ViewCriteria expItemViewCriteria =
            dcIteratorBindings.getViewCriteria();
        expItemVO.applyViewCriteria(expItemViewCriteria);
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this,
                             "customHandleMassAdjustment::expItemVO.getRowCount()::" +
                             expItemVO.getRowCount(), AppsLogger.SEVERE);
        }
        RowSetIterator expItemLine = expItemVO.createRowSetIterator(null);
        while (expItemLine.hasNext()) {
            expItemLine.next();
            Long newExpItemId =
                (Long)expItemLine.getCurrentRow().getAttribute("ExpenditureItemId");
            if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                AppsLogger.write(this,
                                 "customHandleMassAdjustment::newExpItemId::" +
                                 newExpItemId, AppsLogger.SEVERE);
            }
            expItemsLst.add(newExpItemId);
        }
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this,
                             "customHandleMassAdjustment::expItemsLst::" +
                             expItemsLst, AppsLogger.SEVERE);
        }
        if (expItemsLst != null && expItemsLst.size() > 0) {
            OperationBinding operPreBook =
                (OperationBinding)bindings.getOperationBinding("preBookCheck");
            operPreBook.getParamsMap().put("selRecEiIds", expItemsLst);
            operPreBook.execute();
            String preBookResult = operPreBook.getResult().toString();
            if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                AppsLogger.write(this,
                                 "customHandleMassAdjustment::preBookResult::" +
                                 preBookResult, AppsLogger.SEVERE);
            }
            if (preBookResult.equalsIgnoreCase("false")) {
                //handleMassAdjustment call from ReviewAndAdjustBean
                getSeededBeanInstance().handleMassAdjustment(actionEvent);
            } else {
                if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                    AppsLogger.write(this,
                                     "customHandleMassAdjustment::Inside Pre Book ELSE",
                                     AppsLogger.SEVERE);
                }
                FacesMessage errorMessage =
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, null,
                                     pageResBundle.getString("MASSADJUST_PREBOOK_EXPITEMS"));
                FacesContext.getCurrentInstance().addMessage("Error Message",
                                                             errorMessage);
            }
        }
    }

    public void setCurrExpItemId(String currExpItemId) {
        this.currExpItemId = currExpItemId;
    }

    public String getCurrExpItemId() {
        return currExpItemId;
    }

    public void setExpenditureItemId(RichOutputText expenditureItemId) {
        if (expenditureItemId != null) {
            this.expenditureItemId =
                    ComponentReference.newUIComponentReference(expenditureItemId);
        }
    }

    public RichOutputText getExpenditureItemId() {
        return expenditureItemId == null ? null :
               expenditureItemId.getComponent();
    }

    /**
     * This function calls from transfer/split and transper page submit button.
     * @return
     */
    public String transferCustomAction(ActionEvent actionEvent) {
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this, "transferCustomAction::Start()",
                             AppsLogger.SEVERE);
        }
        //Seeded call
        AdjustRegionsBean adjustRegionsBean = getAdjustRegionsBeanInstance();
        adjustRegionsBean.insertRecord(actionEvent);
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this,
                             "transferCustomAction::Seeded functionality called successfully",
                             AppsLogger.SEVERE);
        }
        String adjustmentType =
            (String)ADFUtil.evaluateEL("#{pageFlowScope.adjustType}");
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this,
                             "transferCustomAction:adjustmentType::" + adjustmentType,
                             AppsLogger.SEVERE);
        }
        if (adjustmentType.equalsIgnoreCase("MULTI_SPLIT_TRANS") ||
            adjustmentType.equalsIgnoreCase("TRANSFER")) {
            BindingContext bc = BindingContext.getCurrent();
            DCBindingContainer binding =
                (DCBindingContainer)bc.getCurrentBindingsEntry();
            DCIteratorBinding selectedProjectVO =
                binding.findIteratorBinding("ProjectPatiAdjQueueIterator");
            if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                AppsLogger.write(this,
                                 "transferCustomAction:ROW::" + selectedProjectVO.getCurrentRow(),
                                 AppsLogger.SEVERE);
            }
            Row row = selectedProjectVO.getCurrentRow();
            String selectedProjectNumber = null;
            if (row.getAttribute("ProjectNumber") != null) {
                if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                    AppsLogger.write(this, "transferCustomAction::Inside IF",
                                     AppsLogger.SEVERE);
                }
                selectedProjectNumber =
                        row.getAttribute("ProjectNumber").toString();
            }
            if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                AppsLogger.write(this,
                                 "transferCustomAction::selectedProjectNumber::" +
                                 selectedProjectNumber, AppsLogger.SEVERE);
            }
            List eiIdList =
                (List)ADFUtil.evaluateEL("#{pageFlowScope.rowKeyList}");
            if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                AppsLogger.write(this,
                                 "transferCustomAction::eiIdList::" + eiIdList,
                                 AppsLogger.SEVERE);
            }
            FacesContext fctx = FacesContext.getCurrentInstance();
            ELContext elctx = fctx.getELContext();
            Application appl = fctx.getApplication();
            ExpressionFactory elf = appl.getExpressionFactory();
            BindingContainer bindings =
                (BindingContainer)elf.createValueExpression(elctx,
                                                            "#{bindings}",
                                                            BindingContainer.class).getValue(elctx);
            //Method binding call to update the Own Approval as null in DB table
            OperationBinding operPreBook =
                (OperationBinding)bindings.getOperationBinding("userDef2ColumnUpdateToNull");
            operPreBook.getParamsMap().put("selRecEiIds", eiIdList);
            operPreBook.getParamsMap().put("destProjId",
                                           selectedProjectNumber);
            operPreBook.execute();
            String updateStatus = operPreBook.getResult().toString();
            if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                AppsLogger.write(this,
                                 "transferCustomAction::updateStatus::" + updateStatus,
                                 AppsLogger.SEVERE);
            }
        }
        return null;
    }
    //END:: EXT0104 and EXT0110 Methods

    //Start EXT0320 methods

    public void invoiceImageActionListener(ActionEvent actionEvent) {
        try {
            if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                AppsLogger.write(this, "invoiceImageActionListener::Start()",
                                 AppsLogger.SEVERE);
            }
            Long lngTransactionId = null;
            String strAction = "";
            Map resultMap = null;
            FacesContext fctx = FacesContext.getCurrentInstance();
            ELContext elctx = fctx.getELContext();
            Application appl = fctx.getApplication();
            ExpressionFactory elf = appl.getExpressionFactory();

            ResourceBundle pageResBundle = getExpenditureTypeResourceBundle();
            List lst = selExpItems();
            ArrayList expItemsLst = new ArrayList();
            expItemsLst = (ArrayList)lst;
            if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                AppsLogger.write(this,
                                 "Printing LIST in invoiceImageActionListener :" +
                                 expItemsLst, AppsLogger.SEVERE);
            }
            if (expItemsLst != null && expItemsLst.size() > 0) {
                if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                    AppsLogger.write(this,
                                     "invoiceImageActionListener::selected rows size::" +
                                     expItemsLst.size(), AppsLogger.SEVERE);
                }
                if (expItemsLst.size() >
                    1) { //means multiple row selected , show error message
                    if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                        AppsLogger.write(this,
                                         "invoiceImageActionListener:: multiple row selected , error message is shown",
                                         AppsLogger.SEVERE);
                    }
                    this.setStrImageMessage(pageResBundle.getString("INVOICE_IMAGE_MULTIPLE_ROWSELECTION_MSG"));

                    if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                        AppsLogger.write(this,
                                         "invoiceImageActionListener:: multiple row selected " +
                                         strImageMessage, AppsLogger.SEVERE);
                    }
                    UIComponent source = (UIComponent)actionEvent.getSource();
                    RichPopup.PopupHints hints = new RichPopup.PopupHints();
                    hints.add(RichPopup.PopupHints.HintTypes.HINT_ALIGN_ID,
                              source).add(RichPopup.PopupHints.HintTypes.HINT_LAUNCH_ID,
                                          source).add(RichPopup.PopupHints.HintTypes.HINT_ALIGN,
                                                      RichPopup.PopupHints.AlignTypes.ALIGN_AFTER_START);
                    this.getInvoiceMsgPopup().show(hints);

                } else if (expItemsLst.size() ==
                           1) { // only one row selected call AM method and do the action

                    if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                        AppsLogger.write(this,
                                         "invoiceImageActionListener:: single row selected " +
                                         expItemsLst.size() +
                                         " print list ::" + expItemsLst,
                                         AppsLogger.SEVERE);
                    }

                    try {
                        Object obj = (Object)expItemsLst.get(0);
                        if (obj != null) {
                            lngTransactionId = new Long(String.valueOf(obj));
                        }
                        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                            AppsLogger.write(this,
                                             "SELECTED TRANSACTION ID IN BEAN::" +
                                             lngTransactionId,
                                             AppsLogger.SEVERE);
                        }

                    } catch (Exception e) {
                        AppsLogger.write(this,
                                         "exception in long parsing " + e.getMessage(),
                                         AppsLogger.SEVERE);
                    }
                    AppsLogger.write(this, "AM CALL START", AppsLogger.SEVERE);
                    DCBindingContainer bindings =
                        (DCBindingContainer)BindingContext.getCurrent().getCurrentBindingsEntry();
                    OperationBinding oprBndg =
                        (OperationBinding)bindings.getOperationBinding("getInvoiceAttachmentData");

                    oprBndg.getParamsMap().put("lngTransactionNumber",
                                               lngTransactionId);
                    oprBndg.execute();
                    AppsLogger.write(this, "AM CALLED DONE",
                                     AppsLogger.SEVERE);
                    if (oprBndg.getResult() !=
                        null) { //result received from AM
                        AppsLogger.write(this, "GET THE RESULT FROM AM ",
                                         AppsLogger.SEVERE);
                        resultMap = (HashMap)oprBndg.getResult();
                        strAction = (String)resultMap.get("ACTION");

                        AppsLogger.write(this,
                                         "ACTION IN INVOICE IMAGEinvoiceImageActionListener : " +
                                         strAction, AppsLogger.SEVERE);

                        if (strAction != null &&
                            strAction.trim().length() != 0 &&
                            strAction.equalsIgnoreCase("NOTHING_TO_DO")) {
                            //No Action is required
                            if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                                AppsLogger.write(this,
                                                 "APART FROM BASWARE OR EBFO selected::",
                                                 AppsLogger.SEVERE);
                            }

                            RichPopup.PopupHints hints =
                                new RichPopup.PopupHints();
                            this.setStrImageMessage(pageResBundle.getString("INVOICE_IMAGE_NOT_BASWARE_OR_EBFO_MSG"));
                            this.getInvoiceMsgPopup().show(hints);
                        } else if (strAction != null &&
                                   strAction.trim().length() != 0 &&
                                   strAction.equalsIgnoreCase("BASWARE_DOC_URL_TO_SHOW")) {
                            //Basware Url content to show in popup window
                            String strDocUrl = "";
                            strDocUrl = (String)resultMap.get("DOCUMENT_URL");
                            if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                                AppsLogger.write(this,
                                                 "SELECTED BASWARE DOCUMENT URL::" +
                                                 strDocUrl, AppsLogger.SEVERE);
                            }
                            this.setStrImageMessage("<a href='" + strDocUrl +
                                                    "'>Invoice Details</a>");

                            //                            UIComponent source =
                            //                                (UIComponent)actionEvent.getSource();
                            //                            RichPopup.PopupHints hints =
                            //                                new RichPopup.PopupHints();
                            //                            hints.add(RichPopup.PopupHints.HintTypes.HINT_ALIGN_ID,
                            //                                      source).add(RichPopup.PopupHints.HintTypes.HINT_LAUNCH_ID,
                            //                                                  source).add(RichPopup.PopupHints.HintTypes.HINT_ALIGN,
                            //                                                              RichPopup.PopupHints.AlignTypes.ALIGN_AFTER_START);
                            //                            this.getInvoiceMsgPopup().show(hints);
                            launchNewBrowserWindow(strDocUrl,
                                                   "BASWARE INVOICE DETAILS");
                        } else if (strAction != null &&
                                   strAction.trim().length() != 0 &&
                                   strAction.equalsIgnoreCase("EBFO_SHOW_INVOICE_IN_POPUPWINDOW")) {
                            //EBFP Invoice details to show in PDF format through BI
                            String strInvoiceId = "";
                            strInvoiceId = (String)resultMap.get("INVOICE_ID");

                            if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                                AppsLogger.write(this,
                                                 "IN BEAN EBFO PART  WITH INVOICE ID::" +
                                                 strInvoiceId,
                                                 AppsLogger.SEVERE);
                            }
                            if (strInvoiceId != null &&
                                strInvoiceId.trim().length() != 0) {
                                reportParameters.put("P_INVOICE_NUM",
                                                     new String[] { "" });

                                reportParameters.put("P_INVOICE_ID",
                                                     new String[] { strInvoiceId });
                                RichPopup.PopupHints hints =
                                    new RichPopup.PopupHints();
                                this.getEbfoPreviewPopUp().show(hints);
                            }

                        }

                    } //result receive if end

                } //else completed


            } else { // No expenditure item selected and click the button
                if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                    AppsLogger.write(this,
                                     "invoiceImageActionListener::NO EXPENDITURE ITEM SELECTED",
                                     AppsLogger.SEVERE);
                }

                this.setStrImageMessage(pageResBundle.getString("INVOICE_IMAGE_NO_ROW_SELECTION_MSG"));
                if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                    AppsLogger.write(this,
                                     "invoiceImageActionListener:: no row selected " +
                                     strImageMessage, AppsLogger.SEVERE);
                }
                UIComponent source = (UIComponent)actionEvent.getSource();
                RichPopup.PopupHints hints = new RichPopup.PopupHints();
                hints.add(RichPopup.PopupHints.HintTypes.HINT_ALIGN_ID,
                          source).add(RichPopup.PopupHints.HintTypes.HINT_LAUNCH_ID,
                                      source).add(RichPopup.PopupHints.HintTypes.HINT_ALIGN,
                                                  RichPopup.PopupHints.AlignTypes.ALIGN_AFTER_START);
                this.getInvoiceMsgPopup().show(hints);
            }
        } catch (Exception e) {
            if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                AppsLogger.write(this,
                                 "invoiceImageActionListener:: Exception " +
                                 e.getMessage(), AppsLogger.SEVERE);
            }
        }
    }

    public void launchNewBrowserWindow(String url, String name) {
        String script = "window.open('" + url + "','" + name + "')";
        ExtendedRenderKitService service =
            Service.getRenderKitService(FacesContext.getCurrentInstance(),
                                        ExtendedRenderKitService.class);
        service.addScript(FacesContext.getCurrentInstance(), script);
    }

    public void setInvoiceMsgPopup(RichPopup invoiceMsgPopup) {
        if (invoiceMsgPopup != null) {
            this.invoiceMsgPopup =
                    ComponentReference.newUIComponentReference(invoiceMsgPopup);
        }
    }

    public RichPopup getInvoiceMsgPopup() {
        return invoiceMsgPopup == null ? null : invoiceMsgPopup.getComponent();
    }

    public void setStrImageMessage(String strImageMessage) {
        this.strImageMessage = strImageMessage;
    }

    public String getStrImageMessage() {
        return strImageMessage;
    }

    public void invoiceDetailsShow(DialogEvent dialogEvent) {
        if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
            AppsLogger.write(this, "invoiceDetailsShow::Start()",
                             AppsLogger.SEVERE);
        }
        try {
            if ("ok".equalsIgnoreCase(dialogEvent.getOutcome().toString())) {
                if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                    AppsLogger.write(this, "invoiceDetailsShow::Inside IF",
                                     AppsLogger.SEVERE);
                }
                this.getInvoiceMsgPopup().hide();

            } else {
                if (AppsLogger.isEnabled(AppsLogger.SEVERE)) {
                    AppsLogger.write(this, "invoiceDetailsShow::CANCEL",
                                     AppsLogger.SEVERE);
                }
            }
        } catch (Exception e) {
            AppsLogger.write(this,
                             "invoiceDetailsShow::Exception::" + e.getMessage(),
                             AppsLogger.SEVERE);
            e.printStackTrace();
        }
    }


    public void setReportParameters(Properties reportParameters) {
        this.reportParameters = reportParameters;
    }

    public Properties getReportParameters() {
        return reportParameters;
    }

    public void setEbfoPreviewPopUp(RichPopup ebfoPreviewPopUp) {
        this.ebfoPreviewPopUp = ebfoPreviewPopUp;
    }

    public RichPopup getEbfoPreviewPopUp() {
        return ebfoPreviewPopUp;
    }

    public void ebfoInvoicePreviewShow(DialogEvent dialogEvent) {
        try {
            if ("ok".equalsIgnoreCase(dialogEvent.getOutcome().toString())) {
                this.getEbfoPreviewPopUp().hide();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //End Ext0320 methods
}

