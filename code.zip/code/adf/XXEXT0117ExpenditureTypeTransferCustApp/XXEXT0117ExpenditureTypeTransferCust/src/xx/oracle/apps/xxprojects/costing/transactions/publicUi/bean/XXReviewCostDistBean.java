package xx.oracle.apps.xxprojects.costing.transactions.publicUi.bean;

import java.util.List;
import java.util.logging.Level;

import javax.el.ELContext;
import javax.el.ExpressionFactory;
import javax.el.ValueExpression;

import javax.faces.application.Application;
import javax.faces.context.FacesContext;

import oracle.adf.model.BindingContext;
import oracle.adf.model.OperationBinding;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;
import oracle.adf.view.rich.event.QueryEvent;
import oracle.adf.view.rich.model.AttributeCriterion;
import oracle.adf.view.rich.model.AttributeDescriptor;
import oracle.adf.view.rich.model.ConjunctionCriterion;
import oracle.adf.view.rich.model.Criterion;
import oracle.adf.view.rich.model.QueryDescriptor;

import oracle.apps.fnd.applcore.log.AppsLogger;
import oracle.apps.projects.costing.transactions.publicUi.bean.ReviewCostDist;
import xx.oracle.apps.xxprojects.costing.transactions.Utils.XXADFUtils;
import oracle.jbo.ViewObject;



import oracle.apps.projects.costing.transactions.publicUi.common.ADFUtil;


public class XXReviewCostDistBean extends ReviewCostDist {
    transient ADFLogger _logger = ADFLogger.createADFLogger(this.getClass());

    public String xxReviewPersonName = null;
    public String xxReviewPersonNumber = null;
    public String xxDetailPersonName = null;
    public String xxDetailAssignment = null;
    //private Boolean isXXBCEnabledForBusinessFunction;


    public XXReviewCostDistBean() {
        super();
    }

    /**
     * @param queryEvent
     * Review Cost Distribution  Search Query Customization
     */
    public void xxReviewCostDistSearch(QueryEvent queryEvent) {
        appsLogger("xxReviewCostDistSearch:Starting", Level.SEVERE);


        DCIteratorBinding lBinding =
            ADFUtil.getBindingIterator("ProjectCostDist1Iterator");
        ViewObject vo = lBinding.getViewObject();
        appsLogger("xxReviewCostDistSearch:View" + vo, Level.SEVERE);
//        vo.setWhereClause(null);
//        appsLogger("xxReviewCostDistSearch:vo.getRowCount()",
//                Level.SEVERE);
//        vo.applyViewCriteria(null);
//        appsLogger("xxReviewCostDistSearch: vo.applyViewCriteria(null)",
//                Level.SEVERE);
//        vo.executeQuery();
//      
//       appsLogger("xxReviewCostDistSearch: vo.executeQuery()",
//                Level.SEVERE);
//        appsLogger("xxReviewCostDistSearch:RowCountInitial"
//                    + vo.getRowCount(),
//                Level.SEVERE);
        /* Checking whether has access to white collar transaction details or not */
        //        String userAccess = getUserAccess();
        String access = "";
        Object privilege =
            ADFUtil.evaluateEL("#{securityContext.userGrantedResource['resourceType=FNDResourceType;resourceName=XX_PJC_E265_VIEW_RESOURCE_COSTS;action=launch']}");
        appsLogger("xxEIQuery:previlege" + privilege, Level.SEVERE);
        String privelegeaccess = privilege.toString();
        appsLogger("xxEIQuery:previlegeString" + privelegeaccess,
                   Level.SEVERE);

        if (privelegeaccess != null &&
            privelegeaccess.equalsIgnoreCase("true")) {
            access = "access";
        } else {
            access = "Denied";           
        }
        ADFContext.getCurrent().getSessionScope().put("WhiteCollarAccess",
                                                      access);
        String access1 =
            (String)ADFContext.getCurrent().getSessionScope().get("WhiteCollarAccess");
        appsLogger("xxReviewCostDistSearch:UserAccess" + access1,
                   Level.SEVERE);

         access = "access";
        appsLogger("xxReviewCostDistSearch:UserAccess::" + access,
                   Level.SEVERE);
        /* applying the Restriction on search  if the User not having the access to white collar */
        if (access != "" && access.equalsIgnoreCase("Denied")) {
            String personNumber = null;
            String personName = null;
            QueryDescriptor qdesc =
                (QueryDescriptor)queryEvent.getDescriptor();
            appsLogger("xxReviewCostDistSearch:QueryDescriptor" + qdesc,
                       Level.SEVERE);
            ConjunctionCriterion conCrit = qdesc.getConjunctionCriterion();
            appsLogger("xxReviewCostDistSearch:conCrit" + conCrit,
                       Level.SEVERE);
            //access the list of search fields
            List<Criterion> criterionList = conCrit.getCriterionList();
            appsLogger("xxReviewCostDistSearch:criterianList" + criterionList,
                       Level.SEVERE);
            for (Criterion criterion : criterionList) {
                AttributeDescriptor attrDescriptor =
                    ((AttributeCriterion)criterion).getAttribute();
                appsLogger("xxReviewCostDistSearch:Attributes:" +
                           attrDescriptor.getName(), Level.SEVERE);
                appsLogger("xxReviewCostDistSearch:Values::" +
                           ((AttributeCriterion)criterion).getValues().get(0),
                           Level.SEVERE);
                if (attrDescriptor.getName().equalsIgnoreCase("PersonNumber")) {
                    personNumber =
                            (String)((AttributeCriterion)criterion).getValues().get(0);
                    appsLogger("xxReviewCostDistSearch:personnumber::" +
                               personNumber, Level.SEVERE);

                } else {
                    if (attrDescriptor.getName().equalsIgnoreCase("PersonSearch")) {
                        personName =
                                (String)((AttributeCriterion)criterion).getValues().get(0);
                        appsLogger("xxReviewCostDistSearch:personname::" +
                                   personName, Level.SEVERE);
                    }
                }
                appsLogger("xxReviewCostDistSearch:Selected Values in search::" +
                           personName + personNumber, Level.SEVERE);

            }

            appsLogger("xxReviewCostDistSearch:personnumber" + personNumber,
                       Level.SEVERE);
            appsLogger("xxReviewCostDistSearch:personname" + personName,
                       Level.SEVERE);
            // Applying the filter condition for not fetching the white collar transactions h if the User searchig using the Person Name or Person Number
            if (!(personName == null || personName.equalsIgnoreCase("null") ||
                  personName.trim() == "")) {
                DCBindingContainer bindings =
                    (DCBindingContainer)BindingContext.getCurrent().getCurrentBindingsEntry();
                OperationBinding oper =
                    (OperationBinding)bindings.getOperationBinding("xxReviewandAdjustSearch");
                oper.execute();
                String res = (String)oper.getResult();

                appsLogger("xxReviewCostDistSearch:res::" + res, Level.SEVERE);
                if (!(res.isEmpty())) {
                    vo.setWhereClause("ExpType.EXPENDITURE_TYPE_ID not in (" +
                                      res + ")");
                    vo.executeQuery();

                    appsLogger("xxReviewCostDistSearch:RowCount",
                               Level.SEVERE);
                }

            } 
        }

        //   vo.reset();


        // Calling the Seeded search method
        try {
            
            ReviewCostDist reviewCostDist = this.getInstanceOfBeanInstance();

            appsLogger("xxReviewCostDistSearch:reviewcostdist instance:::: " +
                       reviewCostDist, Level.SEVERE);
            
            appsLogger("xxReviewCostDistSearch:reviewcostdist queryEvent:::: " +
                       queryEvent, Level.SEVERE);
            
            reviewCostDist.collapseSearch(queryEvent);

            appsLogger("xxReviewCostDistSearch:Ending ", Level.SEVERE);
        } catch (Exception e) {
            appsLogger("in side Exception xxReviewCostDistSearch:::::: "+e,
                       Level.SEVERE);

        }

    }

       

    /**
     * @param
     * Checking the User is having the Role for accessing the white collar jobs
     * @return
     */
    public String getUserAccess() {
        appsLogger("getUserAccess:Starting ", Level.SEVERE);
        DCBindingContainer binding =
            (DCBindingContainer)BindingContext.getCurrent().getCurrentBindingsEntry();
        OperationBinding operbind =
            (OperationBinding)binding.getOperationBinding("xxGetWhiteCollarRoles");
        operbind.execute();
        List<String> list = (List<String>)operbind.getResult();
        appsLogger("getUserAccess:Listvalues" + list, Level.SEVERE);
        String userAccess = XXADFUtils.getRole(list);
        appsLogger("getUserAccess:access" + userAccess, Level.SEVERE);
        appsLogger("getUserAccess:Ending ", Level.SEVERE);
        return userAccess;
    }


    /**
     * In local  appsLogger does not work so added this code to make debugging simple.
     * @param message
     * @param level
     */
    public void appsLogger(String message, Level level) {
        //Required for the local debugging.
        _logger.log(Level.SEVERE, message);
        AppsLogger.write(this, message, level);
    }


    /**
     * @param
     * Getting the Seeded Bean Instance
     * @return
     */
    public ReviewCostDist getInstanceOfBeanInstance() {
        FacesContext fctx = FacesContext.getCurrentInstance();
        Application application = fctx.getApplication();
        ExpressionFactory expressionFactory =
            application.getExpressionFactory();
        ELContext context = fctx.getELContext();
        ValueExpression createValueExpression =
            expressionFactory.createValueExpression(context,
                                                    "#{requestScope.ReviewCostDist}",
                                                    ReviewCostDist.class);
        ReviewCostDist beanInstance =
            (ReviewCostDist)createValueExpression.getValue(context);
        return beanInstance;
    }


    public void setXxReviewPersonName(String xxReviewPersonName) {
        this.xxReviewPersonName = xxReviewPersonName;
    }


    /**
     * @param
     * Getting the Person Name based on the User Role
     * @return:PersonName
     */
    public String getXxReviewPersonName() {
        appsLogger("getXxReviewPersonName:Starting", Level.SEVERE);
        String name = (String)ADFUtil.evaluateEL("#{row.PersonName}");
        Long expItemId1 =
            (Long)ADFUtil.evaluateEL("#{row.ExpenditureItemId}");
        appsLogger("getXxReviewPersonName:PersonName" + name, Level.SEVERE);
        appsLogger("getXxReviewPersonName:expitemid" + expItemId1,
                   Level.SEVERE);
        //finding whether user has access to white colar or not
        String access =
            (String)ADFContext.getCurrent().getSessionScope().get("WhiteCollarAccess");
        appsLogger("getXxReviewPersonName:RoleAccess" + access, Level.SEVERE);
        if (access != "" && access.equalsIgnoreCase("Denied")) {
            DCBindingContainer bindings =
                (DCBindingContainer)BindingContext.getCurrent().getCurrentBindingsEntry();
            OperationBinding oper =
                (OperationBinding)bindings.getOperationBinding("xxHasAccess");
            oper.getParamsMap().put("pExpItemId", expItemId1);
            oper.execute();
            String res = (String)oper.getResult();
            appsLogger("getXxReviewPersonName:Result" + res, Level.SEVERE);
            if (res != null && "true".equalsIgnoreCase(res)) {
                xxReviewPersonName = name;
            } else if (res != null && "false".equalsIgnoreCase(res)) {

                xxReviewPersonName = "************";
            }
        } else {
            xxReviewPersonName = name;
        }
        appsLogger("getXxReviewPersonName:return personname" +
                   xxReviewPersonName, Level.SEVERE);
        appsLogger("getXxReviewPersonName:Ending", Level.SEVERE);

        return xxReviewPersonName;
    }

    public void setXxReviewPersonNumber(String xxReviewPersonNumber) {
        this.xxReviewPersonNumber = xxReviewPersonNumber;
    }

    public String getXxReviewPersonNumber() {
        return xxReviewPersonNumber;
    }

    public void setXxDetailPersonName(String xxDetailPersonName) {
        this.xxDetailPersonName = xxDetailPersonName;
    }

    /**
     * @param
     * Getting the Person Name in Expenditure Item detail UI based on the User Role
     * @return:PersonNumber
     */
    public String getXxDetailPersonName() {
        appsLogger("getXxDetailPersonName:Starting", Level.SEVERE);
        String name =
            (String)ADFUtil.evaluateEL("#{bindings.PersonName.inputValue}");
        Long expItemId1 =
            (Long)ADFUtil.evaluateEL("#{bindings.ExpenditureItemId.inputValue}");
        appsLogger("getXxDetailPersonName:DetailPersonName" + name,
                   Level.SEVERE);
        appsLogger("getXxDetailPersonName:DetailExpitemid" + expItemId1,
                   Level.SEVERE);
        //finding whether user has access to white colar or not
        String access =
            (String)ADFContext.getCurrent().getSessionScope().get("WhiteCollarAccess");
        appsLogger("getXxDetailPersonName:RoleAccess" + access, Level.SEVERE);
        if (access != "" && access.equalsIgnoreCase("Denied")) {
            DCBindingContainer bindings =
                (DCBindingContainer)BindingContext.getCurrent().getCurrentBindingsEntry();
            OperationBinding oper =
                (OperationBinding)bindings.getOperationBinding("xxHasAccess");
            oper.getParamsMap().put("pExpItemId", expItemId1);
            oper.execute();
            String res = (String)oper.getResult();
            appsLogger("getXxDetailPersonName:Result" + res, Level.SEVERE);
            if (res != null && "true".equalsIgnoreCase(res)) {
                xxDetailPersonName = name;
            } else if (res != null && "false".equalsIgnoreCase(res)) {

                xxDetailPersonName = "************";
            }
        } else {
            xxDetailPersonName = name;
        }
        appsLogger("getXxDetailPersonName:return personname" +
                   xxDetailPersonName, Level.SEVERE);
        appsLogger("getXxDetailPersonName:Ending", Level.SEVERE);
        return xxDetailPersonName;
    }

    public void setXxDetailAssignment(String xxDetailAssignment) {
        this.xxDetailAssignment = xxDetailAssignment;
    }

    /**
     * @param
     * Getting the Assignment  in Expenditure Item detail UI based on the User Role
     * @return:Assignment Id
     */
    public String getXxDetailAssignment() {
        appsLogger("getXxDetailAssignment:Starting", Level.SEVERE);
        String assignment =
            (String)ADFUtil.evaluateEL("#{bindings.Assignment.inputValue}");
        Long expItemId1 =
            (Long)ADFUtil.evaluateEL("#{bindings.ExpenditureItemId.inputValue}");
        appsLogger("getXxDetailAssignment:DetailPersonName" + assignment,
                   Level.SEVERE);
        appsLogger("getXxDetailAssignment:DetailExpitemid" + expItemId1,
                   Level.SEVERE);
        //finding whether user has access to white colar or not
        String access =
            (String)ADFContext.getCurrent().getSessionScope().get("WhiteCollarAccess");
        appsLogger("getXxDetailAssignment:RoleAccess" + access, Level.SEVERE);
        if (access != "" && access.equalsIgnoreCase("Denied")) {
            DCBindingContainer bindings =
                (DCBindingContainer)BindingContext.getCurrent().getCurrentBindingsEntry();
            OperationBinding oper =
                (OperationBinding)bindings.getOperationBinding("xxHasAccess");
            oper.getParamsMap().put("pExpItemId", expItemId1);
            oper.execute();
            String res = (String)oper.getResult();
            appsLogger("getXxDetailAssignment:Result" + res, Level.SEVERE);
            if (res != null && "true".equalsIgnoreCase(res)) {
                xxDetailAssignment = assignment;
            } else if (res != null && "false".equalsIgnoreCase(res)) {

                xxDetailAssignment = "************";
            }
        } else {
            xxDetailAssignment = assignment;
        }
        appsLogger("getXxDetailAssignment:return personname" +
                   xxDetailAssignment, Level.SEVERE);
        appsLogger("getXxDetailAssignment:Ending", Level.SEVERE);

        return xxDetailAssignment;
    }

    
}
