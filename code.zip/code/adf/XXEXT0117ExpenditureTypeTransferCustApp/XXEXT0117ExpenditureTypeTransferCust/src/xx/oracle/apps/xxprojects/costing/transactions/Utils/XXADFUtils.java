package xx.oracle.apps.xxprojects.costing.transactions.Utils;

import java.util.List;
import javax.el.ELContext;
import javax.el.ExpressionFactory;
import javax.el.MethodExpression;
import javax.el.ValueExpression;
import javax.faces.application.Application;
import javax.faces.context.FacesContext;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.share.ADFContext;
import oracle.adf.share.security.SecurityContext;

public class XXADFUtils {

    /**
     * @param: Role List
     * Checking the whether logged in User is having any one role which is there in the List
     * @return:
     */

    public static String getRole(List<String> xRole) {
        String urole = "";
        ADFContext adfCtx = ADFContext.getCurrent();
        SecurityContext secCntx = adfCtx.getSecurityContext();
        String userroles[] = secCntx.getUserRoles();
        for (int i = 0; i < userroles.length; i++) {
            for (String role : xRole) {
                if (role.equalsIgnoreCase(userroles[i])) {
                    System.out.println("EXT0265:UserRole" + userroles[i]);
                    urole = role;
                    break;
                }
            }

        }
        System.out.println("EXT0265:UserRole" + urole);
        if (urole != "") {
            return "access";
        } else
            return "Denied";

    }

    /**
     * @param: EL Expression
     * Wrapper for invoking the EL Expression
     * @return:
     */

    public static Object invokeEL(String el) {
        return invokeEL(el, new Class[0], new Object[0]);
    }

    public static Object invokeEL(String el, Class[] paramTypes,
                                  Object[] params) {
        FacesContext facesContext = FacesContext.getCurrentInstance();

        ELContext elContext = facesContext.getELContext();
        ExpressionFactory expressionFactory =
            facesContext.getApplication().getExpressionFactory();

        MethodExpression exp =
            expressionFactory.createMethodExpression(elContext, el,
                                                     Object.class, paramTypes);

        return exp.invoke(elContext, params);
    }

    /**
     * @param: Iterator ID
     * Getting the iterator binding
     * @return:
     */

    public static DCIteratorBinding getIteratorBinding(String iterator) {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        Application app = facesContext.getApplication();
        ExpressionFactory elFactory = app.getExpressionFactory();
        ELContext elContext = facesContext.getELContext();
        ValueExpression valueExp =
            elFactory.createValueExpression(elContext, "#{bindings}",
                                            Object.class);
        DCBindingContainer binding =
            (DCBindingContainer)valueExp.getValue(elContext);

        // Here you have to pass the VOIterator name and get the corresponding Iteratorbinding

        DCIteratorBinding itrBinding = binding.findIteratorBinding(iterator);
        return itrBinding;
    }

    /**
     * @param: Iterator ID
     * Evaluting the EL Expression
     * @return:
     */

    public static Object evaluateEL(String el) {

        FacesContext facesContext = FacesContext.getCurrentInstance();

        ELContext elContext = facesContext.getELContext();
        ExpressionFactory expressionFactory =
            facesContext.getApplication().getExpressionFactory();

        ValueExpression exp =
            expressionFactory.createValueExpression(elContext, el,
                                                    Object.class);

        return exp.getValue(elContext);
    }

}

