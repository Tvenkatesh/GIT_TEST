SET SERVEROUTPUT ON;
--/************************************************************************************************************
--*      Program name                     :               Skanska - PJC Expenditure Type Transfer 
--*                                                       (EXT0117)
--*      Source File Name                 :               XXPJC_E0117_FND_MESSAGES.sql
--*      Copyright Information            :               SKANSKA
--*      Author's Name                    :               Sudeep Babu
--*      Purpose                          :               FND Messages creation script
--*
--*      Creation and Modification History 
--*      Ver                             Date                   Author                       Modification
--* -----------------------------------------------------------------------------------------------------------*
--*      1.0                             03.12.2014             Sudeep Babu                  Initial Creation  
--*************************************************************************************************************/
DECLARE
--
   l_position		NUMBER;
--   
BEGIN
--
   l_position := 1;
   fusion.fnd_message_pkg.Create_Message(x_application_short_name  => 'PJC'
                                        ,x_message_name            => 'XXPJC_EXT117_UPDATE_STAT2_MSG'
							            ,x_message_type            => 'ERROR'
							            ,x_message_text            => 'Could not update the interface table status in update_err_stat'
									    ,x_message_number          => l_position
                                        ,x_loggable_alertable      => 'Y');	

   l_position := l_position + 1;
   fusion.fnd_message_pkg.Create_Message(x_application_short_name  => 'PJC'
                                        ,x_message_name            => 'XXPJC_EXT117_SELECT_MSG'
							            ,x_message_type            => 'ERROR'
							            ,x_message_text            => 'Could not fetch mandatory records for expenditure_item_id : {EXP_ITEM_ID}'
									    ,x_message_number          => l_position
                                        ,x_loggable_alertable      => 'Y');
											  
   fusion.fnd_message_pkg.Create_Message_TOKEN(x_application_short_name => 'PJC'
				                              ,x_message_name           => 'XXPJC_EXT117_SELECT_MSG'
											  ,x_token_name             => 'EXP_ITEM_ID'
											  ,x_data_type              => 'NUMBER'
											  ,x_description            => 'Expenditure item ID');
	
   l_position := l_position + 1;
   fusion.fnd_message_pkg.Create_Message(x_application_short_name  => 'PJC'
                                                  ,x_message_name            => 'XXPJC_EXT117_INSERT_NEG_MSG'
							                      ,x_message_type            => 'ERROR'
							                      ,x_message_text            => 'Could not insert negation record into interface table'
									              ,x_message_number          => l_position
                                                  ,x_loggable_alertable      => 'Y');

   l_position := l_position + 1;												   
   fusion.fnd_message_pkg.Create_Message(x_application_short_name  => 'PJC'
                                        ,x_message_name            => 'XXPJC_EXT117_INSERT_POS_MSG'
							            ,x_message_type            => 'ERROR'
							            ,x_message_text            => 'Could not insert positive cost record into interface table'
									    ,x_message_number          => l_position
                                        ,x_loggable_alertable      => 'Y');	

   l_position := l_position + 1;
   fusion.fnd_message_pkg.Create_Message(x_application_short_name  => 'PJC'
                                        ,x_message_name            => 'XXPJC_EXT117_VALDTN_FAIL_MSG'
							            ,x_message_type            => 'ERROR'
							            ,x_message_text            => 'Validation Failure for expenditure_item_id : {EXP_ITEM_ID}'
									    ,x_message_number          => l_position
                                        ,x_loggable_alertable      => 'Y');
											  
   fusion.fnd_message_pkg.Create_Message_TOKEN(x_application_short_name => 'PJC'
				                              ,x_message_name           => 'XXPJC_EXT117_VALDTN_FAIL_MSG'
											  ,x_token_name             => 'EXP_ITEM_ID'
											  ,x_data_type              => 'NUMBER'
											  ,x_description            => 'Expenditure item ID');   
											  
   l_position := l_position + 1;											  
   fusion.fnd_message_pkg.Create_Message(x_application_short_name  => 'PJC'
                                        ,x_message_name            => 'XXPJC_EXT117_CUR_FETCH_MSG'
							            ,x_message_type            => 'ERROR'
							            ,x_message_text            => 'Cursor fetched no records'
									    ,x_message_number          => l_position
                                        ,x_loggable_alertable      => 'Y');
										
   l_position := l_position + 1;										
   fusion.fnd_message_pkg.Create_Message(x_application_short_name  => 'PJC'
                                        ,x_message_name            => 'XXPJC_EXT117_MAIN_EXCEPT_MSG'
							            ,x_message_type            => 'ERROR'
							            ,x_message_text            => 'ERROR in program main block'
									    ,x_message_number          => l_position
                                        ,x_loggable_alertable      => 'Y');	
   
   l_position := l_position + 1;
   fusion.fnd_message_pkg.Create_Message(x_application_short_name   => 'PJC'
                                        ,x_message_name             => 'XXPJC_EXT117_TABLE_CLEANUP_MSG'
							            ,x_message_type             => 'ERROR'
							            ,x_message_text             => 'Error while table cleanup job'
									    ,x_message_number           => l_position
                                        ,x_loggable_alertable       => 'Y');										
   
   COMMIT;
   DBMS_OUTPUT.PUT_LINE('FND_MESSAGES creation successful');
--   
EXCEPTION
--
   WHEN OTHERS THEN
	   ROLLBACK;
	   DBMS_OUTPUT.PUT_LINE('Error while creating FND Messages as Position: '||l_position||' - '||SQLERRM);
--	   
END;
/