SET SERVEROUTPUT ON;
--/************************************************************************************************************
--*      Program name                     :               Skanska - PJC Expenditure Type Transfer 
--*                                                       (EXT0117)
--*      Source File Name                 :               XXPJC_E0117_FND_MESSAGES_CREATION.sql
--*      Copyright Information            :               SKANSKA
--*      Author's Name                    :               Ashwin Kumar
--*      Purpose                          :               FND Messages Creation script 
--*
--*      Creation and Modification History 
--*      Ver                             Date                   Author                       Modification
--* -----------------------------------------------------------------------------------------------------------*
--*      1.0                             15.06.2016             Ashwin Kumar                 Creation of FND Messages in English and Swedish
--*************************************************************************************************************/
-- 
DECLARE
--
   l_position		NUMBER;
--   
BEGIN
--
   l_position := 1;
--   
   --add sequence variable
  l_position := l_position + 1;
  fusion.fnd_message_pkg.Create_Message(x_application_short_name  => 'PJC'
                                        ,x_message_name            => 'XXPJC_EXT117_PROJFUNC_NULL_MSG'
							                          ,x_message_type            => 'ERROR'
                                        ,x_message_text            => 'PROJFUNC_RAW_COST should not be NULL'
									                      ,x_message_number          => l_position
                                        ,x_loggable_alertable      => 'Y');	
   
   update fusion.fnd_messages_tl
   SET message_text  ='PROJFUNC_RAW_COST b�r inte vara NULL'
   WHERE message_name='XXPJC_EXT117_PROJFUNC_NULL_MSG'
   AND language      ='S';
    
   l_position := l_position + 1;                                     
   fusion.fnd_message_pkg.Create_Message(x_application_short_name  => 'PJC'
                                        ,x_message_name            => 'XXPJC_EXT117_SRC_EXP_NULL_MSG'
							                          ,x_message_type            => 'ERROR'
                                        ,x_message_text            => 'SOURCE_EXPENDITURE_ITEM_ID should not be NULL'
									                      ,x_message_number          => l_position
                                        ,x_loggable_alertable      => 'Y');	
   
   update fusion.fnd_messages_tl
   SET message_text  ='SOURCE_EXPENDITURE_ITEM_ID b�r inte vara NULL'
   WHERE message_name='XXPJC_EXT117_SRC_EXP_NULL_MSG'
   AND language      ='S';
  
   l_position := l_position + 1;
   fusion.fnd_message_pkg.Create_Message(x_application_short_name  => 'PJC'
                                        ,x_message_name            => 'XXPJC_EXT117_BRDN_SUM_NULL_MSG'
							                          ,x_message_type            => 'ERROR'
                                        ,x_message_text            => 'BURDEN_SUM_DEST_RUN_ID should be NULL'
									                      ,x_message_number          => l_position
                                        ,x_loggable_alertable      => 'Y');	        
   
   update fusion.fnd_messages_tl
   SET message_text  ='BURDEN_SUM_DEST_RUN_ID b�r vara NULL'
   WHERE message_name='XXPJC_EXT117_BRDN_SUM_NULL_MSG'
   AND language      ='S';
     
   l_position := l_position + 1;
   fusion.fnd_message_pkg.Create_Message(x_application_short_name  => 'PJC'
                                        ,x_message_name            => 'XXPJC_EXT117_NEW_EXP_TYPEID_INVALID_MSG'
							                          ,x_message_type            => 'ERROR'
                                        ,x_message_text            => 'New Expenditure_type_id is invalid'
									                      ,x_message_number          => l_position
                                        ,x_loggable_alertable      => 'Y');	
  
   update fusion.fnd_messages_tl
   SET message_text  ='Nya Expenditure_type_id �r ogiltig'
   WHERE message_name='XXPJC_EXT117_NEW_EXP_TYPEID_INVALID_MSG'
   AND language      ='S';
  
  l_position := l_position + 1;                                    
  fusion.fnd_message_pkg.Create_Message(x_application_short_name  => 'PJC'
                                        ,x_message_name            => 'XXPJC_EXT117_TRNS_SRC_MSG'
							                          ,x_message_type            => 'ERROR'
                                        ,x_message_text            => 'Transaction Source does not exist '
									                      ,x_message_number          => l_position
                                        ,x_loggable_alertable      => 'Y');	 
  
   update fusion.fnd_messages_tl
   SET message_text  ='Transaktions K�lla existerar inte'
   WHERE message_name='XXPJC_EXT117_TRNS_SRC_MSG'
   AND language      ='S';
    
  l_position := l_position + 1;
  fusion.fnd_message_pkg.Create_Message(x_application_short_name  => 'PJC'
                                        ,x_message_name            => 'XXPJC_EXT117_DOCNAME_NULL_MSG'
							                          ,x_message_type            => 'ERROR'
                                        ,x_message_text            => 'Document Name does not exist '
									                      ,x_message_number          => l_position
                                        ,x_loggable_alertable      => 'Y');	 
    
   update fusion.fnd_messages_tl
   SET message_text  ='Dokumentnamn existerar inte'
   WHERE message_name='XXPJC_EXT117_DOCNAME_NULL_MSG'
   AND language      ='S';
  
  l_position := l_position + 1;                                   
  fusion.fnd_message_pkg.Create_Message(x_application_short_name  => 'PJC'
                                        ,x_message_name            => 'XXPJC_EXT117_DOCENTRY_NULL_MSG'
							                          ,x_message_type            => 'ERROR'
                                        ,x_message_text            => 'Document Entry does not exist '
									                      ,x_message_number          => l_position
                                        ,x_loggable_alertable      => 'Y');	
   update fusion.fnd_messages_tl
   SET message_text  ='Dokument Entry existerar inte'
   WHERE message_name='XXPJC_EXT117_DOCENTRY_NULL_MSG'
   AND language      ='S';
  
  COMMIT;  
   DBMS_OUTPUT.PUT_LINE('FND_MESSAGES creation successful ');
--   
EXCEPTION
--
   WHEN OTHERS THEN
	   ROLLBACK;
	   DBMS_OUTPUT.PUT_LINE('Error while creating FND Messages as Position: '||l_position||' - '||SQLERRM);
--	   
END;
/